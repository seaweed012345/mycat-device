from flask import Blueprint, request, jsonify, session, g
from models.user import db, User
from schemas.schemas import UserSchema
from functools import wraps
import requests
import os  # 新增：用于环境变量控制Mock模式

user_bp = Blueprint("user_bp", __name__)
user_schema = UserSchema()
users_schema = UserSchema(many=True)

import json

# ============ 权限校验装饰器 ============

def require_permission(module_key):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            user_id = session.get("user_id")
            if not user_id:
                return jsonify({"error": "未登录"}), 401
            user = User.query.get(user_id)
            if not user:
                return jsonify({"error": "用户不存在"}), 403
            permissions = user.get_permissions()
            if "admin" not in permissions and module_key not in permissions:
                return jsonify({"error": "权限不足"}), 403
            g.current_user = user  # 方便后续接口内直接用
            return f(*args, **kwargs)
        return wrapper
    return decorator

# ============ 用户相关接口 ============

# 注册接口（新建账号） -- 注册一般开放权限（可注册新用户）
@user_bp.route("/users", methods=["POST"])
def create_user():
    data = request.get_json()
    if not all([data.get('username'), data.get('email'), data.get('password')]):
        return jsonify({'error': '缺少必要参数'}), 400
    if User.query.filter((User.username == data['username']) | (User.email == data['email'])).first():
        return jsonify({'error': '用户名或邮箱已注册'}), 400
    user = User(
        username=data["username"],
        email=data["email"],
        role=data.get("role", "user")
    )
    user.set_password(data["password"])
    permissions = data.get("permissions", ["dashboard"])
    user.set_permissions(permissions)
    db.session.add(user)
    db.session.commit()
    return jsonify({'msg': '注册成功', 'user': user_schema.dump(user)}), 201

# 用户列表（建议仅有system权限者可查）
@user_bp.route("/users", methods=["GET"])
@require_permission("system")
def get_users():
    users = User.query.all()
    result = []
    for u in users:
        d = user_schema.dump(u)
        d['permissions'] = u.get_permissions()
        result.append(d)
    return jsonify(result), 200

# 登录接口（含验证码校验！）
@user_bp.route("/user/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    captcha_input = data.get('captcha')
    if not all([username, password, captcha_input]):
        return jsonify({"error": "用户名、密码、验证码必填"}), 400
    captcha_session = session.get('captcha')
    if not captcha_session:
        return jsonify({"error": "请先获取验证码"}), 400
    if captcha_input.lower() != captcha_session.lower():
        return jsonify({"error": "验证码错误"}), 400
    user = User.query.filter_by(username=username).first()
    if not user or not user.check_password(password):
        return jsonify({"error": "用户名或密码错误"}), 401
    session["user_id"] = user.id  # ★【关键】写入session便于接口后续鉴权校验
    session.pop('captcha', None)
    user_dict = user_schema.dump(user)
    user_dict['permissions'] = user.get_permissions()
    return jsonify({"msg": "登录成功", "user": user_dict}), 200

# 编辑用户（仅有system权限用户可以编辑其他用户）
@user_bp.route("/users/<username>", methods=["PATCH"])
@require_permission("system")
def update_user(username):
    user = User.query.filter_by(username=username).first()
    if not user:
        return jsonify({"error": "用户不存在"}), 404
    data = request.get_json()
    if "role" in data:
        user.role = data["role"]
    if "permissions" in data:
        user.set_permissions(data["permissions"])
    db.session.commit()
    user_dict = user_schema.dump(user)
    user_dict['permissions'] = user.get_permissions()
    return jsonify({"msg": "编辑成功", "user": user_dict}), 200

# 删除用户（仅有system权限用户可以删除用户）
@user_bp.route("/users/<username>", methods=["DELETE"])
@require_permission("system")
def delete_user(username):
    user = User.query.filter_by(username=username).first()
    if not user:
        return jsonify({"error": "用户不存在"}), 404
    db.session.delete(user)
    db.session.commit()
    return jsonify({"msg": "已删除"}), 200

@user_bp.route('/wx/login', methods=['POST'])
def wx_login():
    """
    微信小程序一键登录，使用code换取openid
    小程序端 wx.login 后，把 code 送来这里
    """
    # =======================【Mock登录开关】开发环境设置环境变量 WX_DEBUG=1 启用Mock=======
    if os.environ.get("WX_DEBUG"):
        # =======【本地开发Mock返回】无需真实code，直接返回测试openid，正式环境删掉此分支======
        return jsonify({
            'openid': 'test_openid_xxx',
            'session_key': 'mock_session_key',
            'msg': '【Mock开发模式】本地测试自动登录'
        })
    # =======================【以上为开发专用，正式环境请删除或注释】==================
    
    data = request.get_json()
    code = data.get('code')
    if not code:
        return jsonify({'error': 'No code'}), 400

    # 你的小程序appid和secret，务必改为你自己的！
    appid = 'wxd3072964f9ecf9d8'
    secret = '8d7f9ea348666740abf24650dda2adc5'

    wx_url = (
        f"https://api.weixin.qq.com/sns/jscode2session?"
        f"appid={appid}&secret={secret}&js_code={code}&grant_type=authorization_code"
    )
    try:
        resp = requests.get(wx_url, timeout=5)
        wxdata = resp.json()
    except Exception as e:
        return jsonify({'error': '请求微信官方异常', 'detail': str(e)}), 500

    if 'openid' in wxdata:
        return jsonify({
            'openid': wxdata['openid'],
            'session_key': wxdata.get('session_key'),
            'msg': '登录成功'
        })
    else:
        return jsonify({'error': '微信登录失败', 'detail': wxdata}), 400