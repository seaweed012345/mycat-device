# controllers/comm_api.py
from flask import Blueprint, request, jsonify, session, g
from models.comm import db, CommTask, CommLog, CommDeviceStatus
from datetime import datetime
import json
from functools import wraps
from models.user import User

comm_api = Blueprint('comm_api', __name__)

# ===== 权限校验装饰器 =====
def require_permission(module_key):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            user_id = session.get("user_id")
            if not user_id:
                return jsonify({"error": "未登录"}), 401
            user = User.query.get(user_id)
            if not user:
                return jsonify({"error": "用户不存在"}), 403
            permissions = user.get_permissions()
            if "admin" not in permissions and module_key not in permissions:
                return jsonify({"error": "权限不足"}), 403
            g.current_user = user
            return f(*args, **kwargs)
        return wrapper
    return decorator

# 任务列表
@comm_api.route('/api/comm/tasks', methods=['GET'])
@require_permission("comm")
def list_tasks():
    tasks = CommTask.query.order_by(CommTask.id.desc()).all()
    return jsonify([t.to_dict() for t in tasks])

# 新建/编辑任务
@comm_api.route('/api/comm/tasks', methods=['POST'])
@require_permission("comm")
def save_task():
    d = request.json
    if 'id' in d and d['id']:
        t = CommTask.query.get(d['id'])
        if not t:
            return jsonify({'msg':'任务不存在'}), 404
    else:
        t = CommTask()
        db.session.add(t)
    t.name = d['name']
    t.schedule_type = d['schedule_type']
    t.cron_expr = d.get('cron_expr', '')
    t.target_devices = json.dumps(d.get('target_devices', []))
    t.enabled = True
    db.session.commit()
    return jsonify({'msg':'OK'})

# 删除任务
@comm_api.route('/api/comm/tasks/<int:tid>', methods=['DELETE'])
@require_permission("comm")
def del_task(tid):
    t = CommTask.query.get_or_404(tid)
    db.session.delete(t)
    db.session.commit()
    return jsonify({'msg':'deleted'})

# 下发日志
@comm_api.route('/api/comm/logs', methods=['GET'])
@require_permission("comm")
def list_logs():
    logs = CommLog.query.order_by(CommLog.sent_time.desc(), CommLog.id.desc()).limit(100).all()
    return jsonify([l.to_dict() for l in logs])

# 设备通讯状态
@comm_api.route('/api/comm/device_status', methods=['GET'])
@require_permission("comm")
def device_status():
    status = CommDeviceStatus.query.order_by(CommDeviceStatus.device_mac).all()
    return jsonify([d.to_dict() for d in status])

# 手动下发
@comm_api.route('/api/comm/manual_downlink', methods=['POST'])
@require_permission("comm")
def manual_downlink():
    d = request.json
    log = CommLog(
        sent_time=datetime.now(),
        task_id=d.get('task_id'),
        device_mac=d.get('device_mac'),
        payload=json.dumps(d.get('payload')),
        status='success',
        response=json.dumps({'msg':'模拟回包'}, ensure_ascii=False),
        error=''
    )
    db.session.add(log)
    dev = CommDeviceStatus.query.filter_by(device_mac=d.get('device_mac')).first()
    if not dev:
        dev = CommDeviceStatus(
            device_mac=d.get('device_mac'),
            online=True,
            last_online=datetime.now(),
            downlink_count=1,
            failure_count=0
        )
        db.session.add(dev)
    else:
        dev.online = True
        dev.last_online = datetime.now()
        dev.downlink_count = (dev.downlink_count or 0) + 1
    db.session.commit()
    return jsonify({'msg':'downlink sent'})