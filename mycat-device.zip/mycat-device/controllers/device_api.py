# controllers/device_api.py
from flask import Blueprint, request, jsonify
from models.device import db, Device, DeviceUser
from models.user import User
from flask import current_app
import redis  # 确认服务器已安装Redis和python-redis

device_api = Blueprint('device_api', __name__)

# ===== 获取我的所有设备（无论owner/viewer） =====
@device_api.route('/mylist', methods=['GET'])
def my_device_list():
    openid = request.args.get('openid') or request.json.get('openid')
    if not openid:
        return jsonify({'error': '缺少openid'}), 400
    binds = DeviceUser.query.filter_by(user_openid=openid).all()
    res = []
    for b in binds:
        device = Device.query.filter_by(mac=b.device_mac).first()
        if device:
            item = device.to_dict()
            item['role'] = b.role
            item['bind_time'] = b.bind_time
            res.append(item)
    return jsonify(res)

# ===== 扫码配网/绑定设备（一个用户绑一台新设备） =====
@device_api.route('/bind', methods=['POST'])
def bind_device():
    data = request.json
    openid = data.get('openid')
    mac = data.get('mac')
    if not openid or not mac:
        return jsonify({'error': '参数缺失'}), 400
    device = Device.query.filter_by(mac=mac).first()
    if not device:
        return jsonify({'error': '设备不存在'}), 404
    # 校验是否已绑定过（防止重复）
    if DeviceUser.query.filter_by(device_mac=mac, user_openid=openid).first():
        return jsonify({'msg': '已绑定，无需重复操作'})
    # 默认第一个绑定为owner，其它为viewer
    role = 'owner' if DeviceUser.query.filter_by(device_mac=mac).count() == 0 else 'viewer'
    bind = DeviceUser(device_mac=mac, user_openid=openid, role=role)
    db.session.add(bind)
    db.session.commit()
    return jsonify({'msg': '绑定成功', 'role': role})

# ===== 解绑设备（解除绑定，设备与用户解绑） =====
@device_api.route('/unbind', methods=['POST'])
def unbind_device():
    data = request.json
    openid = data.get('openid')
    mac = data.get('mac')
    if not openid or not mac:
        return jsonify({'error': '参数缺失'}), 400
    bind = DeviceUser.query.filter_by(device_mac=mac, user_openid=openid).first()
    if bind:
        db.session.delete(bind)
        db.session.commit()
        return jsonify({'msg': '解绑成功'})
    else:
        return jsonify({'error': '未绑定该设备'}, 400)

# ===== 设备成员（分享）列表 =====
@device_api.route('/members', methods=['GET'])
def device_members():
    mac = request.args.get('mac')
    if not mac:
        return jsonify({'error': '缺少设备mac'}), 400
    members = DeviceUser.query.filter_by(device_mac=mac).all()
    res = []
    for m in members:
        res.append({'openid': m.user_openid, 'role': m.role, 'bind_time': m.bind_time})
    return jsonify(res)

# ===== 分享设备（生成分享码，前端可直接用mac作为“邀请码”）======
# 绑定入口 /bind 已实现，只要知道mac和“主人允许”即可绑定

# ===== 移除成员（设备拥有者踢掉成员） =====
@device_api.route('/remove_member', methods=['POST'])
def remove_member():
    data = request.json
    mac = data.get('mac')
    openid = data.get('openid')      # 发起操作的用户
    target_openid = data.get('target_openid')  # 要移除的对象openid
    if not mac or not openid or not target_openid:
        return jsonify({'error': '参数不足'}), 400
    # 只有owner有权踢人
    myself = DeviceUser.query.filter_by(device_mac=mac, user_openid=openid).first()
    if not myself or myself.role != 'owner':
        return jsonify({'error': '无权操作'}), 403
    target = DeviceUser.query.filter_by(device_mac=mac, user_openid=target_openid).first()
    if not target:
        return jsonify({'error': '目标不存在'}, 400)
    db.session.delete(target)
    db.session.commit()
    return jsonify({'msg': '移除成功'})

# ===== 设备新增/列表接口（管理后台用，可选加权限控制） =====
@device_api.route('/', methods=['POST'])
def add_device():
    data = request.json
    if not data.get('mac'):
        return jsonify({'error': 'MAC不能为空'}), 400
    if Device.query.filter_by(mac=data['mac']).first():
        return jsonify({'error': 'MAC已存在'}), 400
    dev = Device(
        mac=data['mac'],
        sn=data.get('sn', ''),
        alias=data.get('alias', ''),
        group=data.get('group', ''),
        status=data.get('status', ''),
        owner=data.get('owner', ''),
        phone=data.get('phone', ''),
        createTime=data.get('createTime', ''),
        breed=data.get('breed', ''),
        age=data.get('age', ''),
        gender=data.get('gender', ''),
        neutered=bool(data.get('neutered', False)),
    )
    db.session.add(dev)
    db.session.commit()
    return jsonify({'code': 0, 'msg': 'success'})



# ====== 小程序上传设备配网WiFi信息 ======
# 推荐用全局Redis连接池生产环境实际可抽取
r = redis.Redis(decode_responses=True)

@device_api.route('/push_wifi_config', methods=['POST'])
def push_wifi_config():
    data = request.json
    mac = data.get('mac')
    ssid = data.get('ssid')
    password = data.get('password')
    if not mac or not ssid or not password:
        return jsonify({'success': False, 'msg': '参数不全'})
    # 存到redis，设置10分钟有效
    r.hmset(f'wifi_config:{mac}', {'ssid': ssid, 'password': password})
    r.expire(f'wifi_config:{mac}', 600)
    return jsonify({'success': True, 'msg': 'WiFi配置已保存，等待设备来取'})

# ====== 设备端拉取自己的WiFi配置（设备配网用） ======
@device_api.route('/poll_wifi_config', methods=['POST'])
def poll_wifi_config():
    data = request.json
    mac = data.get('mac')
    if not mac:
        return jsonify({'success': False, 'msg': '缺少mac'})
    info = r.hgetall(f'wifi_config:{mac}')
    if not info:
        return jsonify({'success': False, 'msg': '未找到配网配置'})
    r.delete(f'wifi_config:{mac}')  # 配网后即删，防止泄漏
    return jsonify({'success': True, 'ssid': info['ssid'], 'password': info['password']})

@device_api.route('/', methods=['GET'])
def list_devices():
    keyword = request.args.get('keyword', '')
    query = Device.query
    if keyword:
        like = f'%{keyword}%'
        query = query.filter(
            (Device.mac.like(like)) |
            (Device.sn.like(like)) |
            (Device.group.like(like)) |
            (Device.alias.like(like)) |
            (Device.owner.like(like)) |
            (Device.phone.like(like))
        )
    devices = query.order_by(Device.id.desc()).all()
    return jsonify([d.to_dict() for d in devices])