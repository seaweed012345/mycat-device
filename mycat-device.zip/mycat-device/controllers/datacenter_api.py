# src/server/controllers/datacenter_api.py
from flask import Blueprint, request, jsonify, session, g
from models.datacenter import db, DeviceData
from functools import wraps
from models.user import User

datacenter_api = Blueprint('datacenter_api', __name__)

# ===== 权限校验装饰器 =====
def require_permission(module_key):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            user_id = session.get("user_id")
            if not user_id:
                return jsonify({"error": "未登录"}), 401
            user = User.query.get(user_id)
            if not user:
                return jsonify({"error": "用户不存在"}), 403
            permissions = user.get_permissions()
            if "admin" not in permissions and module_key not in permissions:
                return jsonify({"error": "权限不足"}), 403
            g.current_user = user
            return f(*args, **kwargs)
        return wrapper
    return decorator

# 查询（带筛选）
@datacenter_api.route('/', methods=['GET'])
@require_permission("datacenter")
def get_devices():
    filter_type = request.args.get("filterType")
    query_value = request.args.get("queryValue")
    query = DeviceData.query
    if filter_type and query_value:
        query = query.filter(getattr(DeviceData, filter_type).like(f"%{query_value}%"))
    items = [item.to_dict() for item in query.all()]
    return jsonify(items)

# 新增
@datacenter_api.route('/', methods=['POST'])
@require_permission("datacenter")
def add_data():
    data = request.json
    dev = DeviceData(**data)
    db.session.add(dev)
    db.session.commit()
    return jsonify({'code': 0, 'msg': 'success'})

# 编辑
@datacenter_api.route('/<int:row_id>', methods=['PATCH'])
@require_permission("datacenter")
def edit_data(row_id):
    dev = DeviceData.query.get_or_404(row_id)
    for k, v in request.json.items():
        if hasattr(dev, k):
            setattr(dev, k, v)
    db.session.commit()
    return jsonify({'code': 0, 'msg': 'success'})

# 删除
@datacenter_api.route('/<int:row_id>', methods=['DELETE'])
@require_permission("datacenter")
def del_data(row_id):
    dev = DeviceData.query.get_or_404(row_id)
    db.session.delete(dev)
    db.session.commit()
    return jsonify({'code': 0, 'msg': 'success'})

# 单条设备详情
@datacenter_api.route('/<int:row_id>', methods=['GET'])
@require_permission("datacenter")
def get_device_detail(row_id):
    item = DeviceData.query.get_or_404(row_id)
    return jsonify(item.to_dict())