# controllers/wx_api.py
import requests
from flask import Blueprint, request, jsonify
from models.user import db, User

wx_bp = Blueprint('wx_bp', __name__)

# 请填写你的真实AppID/AppSecret（建议放配置文件里）
WEIXIN_APPID = 'wxd3072964f9ecf9d8'
WEIXIN_SECRET = 'b404ec87dfb85492f0dbcd23a6d2565d'

@wx_bp.route('/api/wx/login', methods=['POST'])
def wx_login():
    code = request.json.get('code')
    if not code:
        return jsonify({'error': '缺少code'}), 400

    wxurl = (
        f"https://api.weixin.qq.com/sns/jscode2session"
        f"?appid={WEIXIN_APPID}&secret={WEIXIN_SECRET}"
        f"&js_code={code}&grant_type=authorization_code"
    )
    resp = requests.get(wxurl)
    wxdata = resp.json()
    if 'openid' not in wxdata:
        return jsonify({'error': '微信code校验失败', 'wx_resp': wxdata}), 400
    openid = wxdata['openid']
    user = User.query.filter_by(wx_openid=openid).first()
    if not user:
        gen_username = f"wx_{openid[:8]}"
        fake_email = f"{openid[:8]}@wx.fake"
        user = User(username=gen_username, wx_openid=openid, email=fake_email, role='user')
        user.set_password("wxuser_default_123456")  # 用原有加密方法生成默认hash
        db.session.add(user)
        db.session.commit()
    return jsonify({'msg': '登录成功', 'openid': openid, 'user_id': user.id})