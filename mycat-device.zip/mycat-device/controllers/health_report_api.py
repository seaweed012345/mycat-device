# controllers/health_report_api.py
from flask import Blueprint, request, jsonify, session, g
from models.health_report import db, HealthEvalConfig, HealthReport
import json
from functools import wraps
from models.user import User

health_report_api = Blueprint('health_report_api', __name__)

# ===== 权限校验装饰器 =====
def require_permission(module_key):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            user_id = session.get("user_id")
            if not user_id:
                return jsonify({"error": "未登录"}), 401
            user = User.query.get(user_id)
            if not user:
                return jsonify({"error": "用户不存在"}), 403
            permissions = user.get_permissions()
            if "admin" not in permissions and module_key not in permissions:
                return jsonify({"error": "权限不足"}), 403
            g.current_user = user
            return f(*args, **kwargs)
        return wrapper
    return decorator

# ========== 评估时间段设置 ==========
@health_report_api.route('/api/settings/eval_period', methods=['GET'])
@require_permission("stats")
def get_eval_period():
    cfg = HealthEvalConfig.query.first()
    if not cfg:
        cfg = HealthEvalConfig(eval_period='23-0')
        db.session.add(cfg)
        db.session.commit()
    return jsonify({'eval_period': cfg.eval_period})

@health_report_api.route('/api/settings/eval_period', methods=['POST'])
@require_permission("stats")
def set_eval_period():
    val = request.json.get('eval_period')
    cfg = HealthEvalConfig.query.first()
    if not cfg:
        cfg = HealthEvalConfig(eval_period=val)
        db.session.add(cfg)
    else:
        cfg.eval_period = val
    db.session.commit()
    return jsonify({'msg':'OK'})

# ========== 健康报告列表 ==========
@health_report_api.route('/api/health/report/list', methods=['GET'])
@require_permission("stats")
def list_report():
    period = request.args.get('period')
    search = request.args.get('search', '').strip()
    query = HealthReport.query
    if period:
        query = query.filter(HealthReport.analyze_time.contains(period))
    if search:
        like = f'%{search}%'
        query = query.filter(
            (HealthReport.mac.like(like)) | (HealthReport.breed.like(like)) |
            (HealthReport.sex.like(like)) | (HealthReport.score_level.like(like)) |
            (HealthReport.analyze_time.like(like))
        )
    result = [r.to_dict() for r in query.order_by(HealthReport.analyze_time.desc()).all()]
    return jsonify(result)

# ========== 报告详情 ==========
@health_report_api.route('/api/health/report/detail', methods=['GET'])
@require_permission("stats")
def report_detail():
    report_id = request.args.get('report_id')
    report = HealthReport.query.filter_by(report_id=report_id).first_or_404()
    return jsonify(report.to_dict())

# ========== 保存备注 ==========
@health_report_api.route('/api/health/report/mark', methods=['POST'])
@require_permission("stats")
def save_mark():
    report_id = request.json.get('report_id')
    mark = request.json.get('mark', '')
    report = HealthReport.query.filter_by(report_id=report_id).first_or_404()
    report.comment = mark
    db.session.commit()
    return jsonify({'msg': 'OK'})

# ========== 重新分析 ==========
@health_report_api.route('/api/health/report/rerun', methods=['POST'])
@require_permission("stats")
def rerun_report():
    report_id = request.json.get('report_id')
    report = HealthReport.query.filter_by(report_id=report_id).first_or_404()
    # TODO: 这里应接AI分析服务/API，自动刷新得分/分级/主trigger等
    import random
    report.score = round(random.uniform(60, 100), 2)
    report.score_level = 'A' if report.score > 85 else 'B' if report.score > 70 else 'C'
    db.session.commit()
    return jsonify({'score': report.score, 'score_level': report.score_level})