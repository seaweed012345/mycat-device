from flask import Blueprint, send_file, session
import random, string
from captcha.image import ImageCaptcha

captcha_bp = Blueprint('captcha_bp', __name__)

@captcha_bp.route("/api/captcha")
def get_captcha():
    chars = string.ascii_uppercase + string.digits
    code = ''.join(random.choices(chars, k=4))
    session['captcha'] = code
    image = ImageCaptcha(width=120, height=30)
    data = image.generate(code)
    return send_file(data, mimetype='image/png')