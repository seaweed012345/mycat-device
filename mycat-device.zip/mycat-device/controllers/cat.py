from flask import Blueprint, request, jsonify
cat_bp = Blueprint('cat', __name__)

@cat_bp.route('/cat/ping', methods=['GET'])
def cat_ping():
    return jsonify({"msg": "cat ok"})