import os
from flask import Flask, request, jsonify

app = Flask(__name__)

# ============ 配置存储相关（新核心） ================
# 自动定位到 config/eval_period.cfg（主目录和 ai 子目录兼容）
AI_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(AI_DIR, ".."))
CONFIG_DIR = os.path.join(ROOT_DIR, "config")
os.makedirs(CONFIG_DIR, exist_ok=True)
EVAL_PERIOD_FILE = os.path.join(CONFIG_DIR, "eval_period.cfg")

def get_eval_period():
    """读取评估时间段配置，默认为23-0"""
    if not os.path.isfile(EVAL_PERIOD_FILE):
        with open(EVAL_PERIOD_FILE, 'w', encoding='utf-8') as f:
            f.write("23-0")
    with open(EVAL_PERIOD_FILE, 'r', encoding='utf-8') as f:
        val = f.read().strip()
        if '=' in val:
            val = val.split('=')[1].strip()
        return val if val else "23-0"

def set_eval_period(period):
    """写入评估时间段配置"""
    with open(EVAL_PERIOD_FILE, 'w', encoding='utf-8') as f:
        f.write(period)

# ============ Mock 健康分析报告数据 ================
FAKE_DB = {
    "reports": [
        {
            "report_id": "mac001_20260409",
            "mac": "mac001",
            "breed": "英短",
            "sex": "F",
            "analyze_time": "2026-04-09 23:11",
            "score": 82,
            "score_level": "需关注",
            "main_triggers": ["体重超标", "进食量低"],
            "all_triggers": ["体重超标", "进食量低", "饮水偏低"],
            "raw_risk_dict": {"肥胖": 1.2, "肾病": 0.6},
            "cat_obj_stats": {"weight_now": 5.2, "age_month": 26, "...": "..."},
            "feedback_dict": {"便稀": False, "精神差": False},
            "comment": ""
        },
        # 可扩展更多报告数据
    ]
}

# ================= API 实现 ======================

@app.route("/api/settings/eval_period", methods=["GET", "POST"])
def eval_period_api():
    if request.method == "POST":
        data = request.get_json(force=True)
        new_period = data.get("eval_period")
        if new_period:
            set_eval_period(new_period)
        return jsonify({"eval_period": get_eval_period()})
    else:
        return jsonify({"eval_period": get_eval_period()})

@app.route("/api/health/report/list", methods=["GET"])
def health_report_list():
    period = request.args.get("period") or get_eval_period()
    search = request.args.get("search", "").strip().lower()
    results = []
    for r in FAKE_DB["reports"]:
        # 按分析时间段（如"23-0"）过滤
        is_in_period = period in r.get("analyze_time", "")
        text = f"{r.get('mac','')} {r.get('breed','')} {r.get('score_level','')} {r.get('analyze_time','')}".lower()
        is_search = all(key in text for key in search.split()) if search else True
        if is_in_period and is_search:
            results.append(r)
    return jsonify(results)

@app.route("/api/health/report/detail", methods=["GET"])
def health_report_detail():
    report_id = request.args.get("report_id")
    for r in FAKE_DB['reports']:
        if r['report_id'] == report_id:
            return jsonify(r)
    return jsonify({"error": "not found"}), 404

@app.route("/api/health/report/rerun", methods=["POST"])
def health_report_rerun():
    report_id = request.json.get("report_id")
    for r in FAKE_DB['reports']:
        if r['report_id'] == report_id:
            # 实际应重新AI分析生成新分数，这里增加1分演示
            r["score"] = int(r["score"]) + 1
            return jsonify({**r, "msg": "已重新分析（demo）"})
    return jsonify({"error": "not found"}), 404

@app.route("/api/health/report/mark", methods=["POST"])
def health_report_mark():
    report_id = request.json.get("report_id")
    mark = request.json.get("mark", "")
    for r in FAKE_DB['reports']:
        if r['report_id'] == report_id:
            r["comment"] = mark
            return jsonify({"ok": True})
    return jsonify({"error": "not found"}), 404

# --------- 你原有健康趋势演示API ---------
def get_health_visual_data(cat_id):
    # 首页趋势/历史可用
    return {
      "score_trend": [
          {"date":"2026-04-07", "score":81},
          {"date":"2026-04-08", "score":78},
          {"date":"2026-04-09", "score":82},
      ],
      "weight_trend": [
          {"date": "2026-04-07", "weight": 4.8},
          {"date": "2026-04-08", "weight": 4.9},
          {"date": "2026-04-09", "weight": 5.2},
      ],
      "alert_history": [
          {"date":"2026-04-09", "level":"需关注", "triggers":["体重超标"]},
      ],
      # 可扩展其他
    }

# 如需启动flask:
# if __name__ == '__main__':
#     app.run(port=8001, debug=True)