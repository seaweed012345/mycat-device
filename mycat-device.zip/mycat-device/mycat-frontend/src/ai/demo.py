from trait_reference import TraitLib
from data_loader import load_cat_data
from feature_engineering import calc_sliding_stats, recent_trends
from health_score import health_risk_pipeline
from feedback_interface import get_client_feedback

# 1. 载入体重库（如在src/ai/目录下需要填全路径）
tlib = TraitLib("src/ai/体重参考库中国国情.txt")

cat_id = 'ABC001'
df = load_cat_data(cat_id)
df = calc_sliding_stats(df)
stats = recent_trends(df)

# ==== 自动查表：从数据中心获取基本信息 ====
# 这里假设你stats中包含"breed"、"sex"、"age_days"，若没有请根据实际情况补充
breed = stats.get('breed', "Domestic Shorthair (中华田园猫)")
sex = stats.get('sex', 'F')
age_days = stats.get('age_days', 365)
# 默认英短母猫180天（演示可灵活切换）
ref_min, ref_max = tlib.ref_weight(breed, sex, age_days)
ref_weight = (ref_min + ref_max) / 2

stats["ref_weight"] = ref_weight
stats["weight_now"] = df["weight"].values[-1]

# 体重趋势周期准备（如recent_trends返回weight_trend_14/30/60/90/180）
feedback = get_client_feedback()

results = health_risk_pipeline(stats, feedback)
print("疾病风险分析(排序):")
for dis, val in results:
    print(f"{dis}: {val:.2f}")