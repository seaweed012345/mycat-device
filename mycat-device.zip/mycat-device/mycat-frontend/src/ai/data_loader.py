import pandas as pd

def load_cat_data(cat_id, since_days=180):
    # 采集���只猫所有检测指标，最近N天序列
    # 建议按实际数据表格式返回DataFrame或dict
    # e.g. ["date", "weight", "food", "water", "stool_count", ...]
    return pd.read_csv(f"data/cat_{cat_id}_history.csv")  # 示例