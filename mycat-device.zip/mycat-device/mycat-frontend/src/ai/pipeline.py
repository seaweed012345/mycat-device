def health_risk_pipeline(cat_obj_stats, feedback_dict):
    # 原有客观+主观融合...
    risks = compute_objective_risks(cat_obj_stats)
    risks = combine_with_subjective(risks, feedback_dict)
    exc_risks = compute_excretion_risks(cat_obj_stats, feedback_dict)
    for k, v in exc_risks.items():
        risks[k] = risks.get(k, 0) + v

    # 环境判据
    env_risks = compute_env_risks(cat_obj_stats)
    for k, v in env_risks.items():
        risks[k] = risks.get(k, 0) + v

    sorted_risks = sorted(risks.items(), key=lambda x: -x[1])
    return sorted_risks