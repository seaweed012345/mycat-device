import json

def get_client_feedback():
    """
    示例接口——应由前端/用户输���实际获得（可适配成表单收集）。
    你的健康引擎主流程会取本函数结果。
    """
    # 返回主观反馈（此处举例，可视化界面应由实际提交驱动）
    return {
        "咳嗽": False,
        "呕吐": False,
        "食欲减退": False,
        "腹泻": False,
        # 饮水相关主观反馈
        "饮水异常多": False,
        "饮水异常少": False,
        # 手动补喂输入
        "manual_feed": False,
        "manual_feed_amount": 0   # 克
        # 更多症状请持续扩展
    }

def submit_feedback(cat_id, feedback):
    # 记录反馈到json（或者数据库），可供训练、测试等用
    with open(f'data/feedback_{cat_id}.json', 'a', encoding='utf-8') as f:
        f.write(json.dumps(feedback, ensure_ascii=False)+'\n')