def detect_alerts(stats, threshold):
    alerts = []
    if abs(stats["weight_diff_pct"]) > threshold["weight_warn_pct"]:
        alerts.append("体重异常")
    if stats["food_trend"] < -threshold["food_daily_pct"]:
        alerts.append("进食量减少预警")
    # ...其它如水、排泄、HR、HRV
    return alerts