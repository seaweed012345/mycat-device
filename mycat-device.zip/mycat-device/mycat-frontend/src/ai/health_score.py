from .model_config import default_weights, symptom_disease_weights, default_threshold, default_env_threshold
from trait_reference import TraitLib
tlib = TraitLib("src/ai/体重参考库中国国情.txt")

# ====================1. 标准健康结构体和辅助函数===================
def health_report_template():
    return {
        "score": 0,
        "score_level": "正常",
        "main_triggers": [],
        "all_triggers": [],
        "raw_risk_dict": {},
        "ml_score": None,
        "rule_score": None,
        "suggest": ""
    }

def score_level(score):
    if score >= 86:
        return "高危"
    elif score >= 70:
        return "需关注"
    else:
        return "正常"

def gen_suggest(level, triggers):
    if level == "高危":
        return "多项健康参数异常，请尽快就医并上传完整记录。"
    elif level == "需关注":
        return "部分健康参数偏离正常，请连续跟踪并及时干预，如有加重请就医。"
    else:
        return "体征正常，持续关注即可。"


# ====================2. 风险分、解释、融合主流程===================
def compute_single_risks(cat_obj_stats, feedback_dict):
    """
    合并所有单项风险，使用你现有的判据体系（调用其它 compute_*_risks，见下方），合并为1个dict
    """
    risks = compute_objective_risks(cat_obj_stats)
    risks = combine_with_subjective(risks, feedback_dict)
    exc_risks = compute_excretion_risks(cat_obj_stats, feedback_dict)
    for k, v in exc_risks.items():
        risks[k] = risks.get(k, 0.0) + v
    env_risks = compute_env_risks(cat_obj_stats)
    for k, v in env_risks.items():
        risks[k] = risks.get(k, 0.0) + v
    return risks

def get_dynamic_refs(cat_obj_stats, tlib=tlib):
    """根据 cat_obj_stats 字典内容返回当前个体全面基线
       支持字段不全、自动兜底
    """
    breed = cat_obj_stats.get('breed', 'Domestic Shorthair (中华田园猫)').strip()
    sex = cat_obj_stats.get('sex', 'F').strip()
    # 年龄天缺失也支持月龄自动转为天
    age_days = int(cat_obj_stats.get('age_days', cat_obj_stats.get('age_month', 12) * 30))
    is_neutered = cat_obj_stats.get('is_neutered', False)
    weight_now = float(cat_obj_stats.get('weight_now', 3.5))
    
    wmin, wmax = tlib.ref_weight(breed, sex, age_days)
    ref_weight = (wmin + wmax) / 2 if wmin and wmax else weight_now

    food_ref = ref_weight * 30 # g/天
    water_ref = ref_weight * 60 # ml/天
    hr_low, hr_high = 120, 220
    age_month = age_days // 30
    if age_month < 10:
        food_ref *= 1.15
        water_ref *= 1.15
        hr_low, hr_high = 160, 240
    if is_neutered:
        food_ref *= 0.9
    return {
        "weight_min": wmin/1000,
        "weight_max": wmax/1000,
        "weight_ref": ref_weight,
        "food_ref": food_ref,
        "water_ref": water_ref,
        "hr_ref_range": (hr_low, hr_high)
    }

def compute_triggers(cat_obj_stats, feedback_dict):
    triggers = []
    refs = get_dynamic_refs(cat_obj_stats)

    # 体重智能检测
    weight = float(cat_obj_stats.get("weight_now", refs["weight_ref"]))
    if weight < refs["weight_min"]:
        triggers.append(f"体重低于参考下限{refs['weight_min']:.1f}kg，发育或营养需关注。")
    if weight > refs["weight_max"]:
        triggers.append(f"体重高于参考上限{refs['weight_max']:.1f}kg，肥胖风险提升。")
    # 进食
    food = float(cat_obj_stats.get("food_now", refs["food_ref"]))
    if food < refs["food_ref"]*0.7:
        triggers.append(f"进食量小于本猫个体推荐的70%（{food:.0f}g），警惕消化及肝营养问题。")
    elif food > refs["food_ref"]*1.4:
        triggers.append(f"进食远超同龄/同体重基线，警惕甲亢/糖尿。")
    # 饮水
    water = float(cat_obj_stats.get("water_now", refs["water_ref"]))
    if water < refs["water_ref"]*0.7:
        triggers.append("饮水小于本猫基线，关注脱水或食欲不振。")
    elif water > refs["water_ref"]*1.4:
        triggers.append("饮水高于需求，关注肾/激素异常。")
    # 心率
    hr = float(cat_obj_stats.get("hr_now", 0))
    hr_low, hr_high = refs["hr_ref_range"]
    if hr and hr < hr_low:
        triggers.append(f"心率低于年龄/品种基线（{hr}bpm<{hr_low}），警惕心脏等疾病。")
    elif hr and hr > hr_high:
        triggers.append(f"心率大于参考上限（{hr}bpm>{hr_high}），应激/心脏危险。")
    # 排泄/主观反馈/环境因子沿用你原有或继续扩展
    if cat_obj_stats.get("excretion_count", 0) > 4:
        triggers.append("如厕频率异常增多")
    if cat_obj_stats.get("excretion_count", 0) < 1:
        triggers.append("如厕频率严重减少")
    if cat_obj_stats.get("hrv_now", 60) < 35:
        triggers.append("心率变异性HRV低，关注应激/炎症/心脏")
    if feedback_dict.get("便稀", False):
        triggers.append("主观反馈有稀便，腹泻风险提升")
    if feedback_dict.get("便硬", False):
        triggers.append("主观反馈有便秘情况")
    if cat_obj_stats.get("temp_now", 24) < 17 or cat_obj_stats.get("temp_now", 24) > 30:
        triggers.append("环境温度不适宜")
    if cat_obj_stats.get("pm25_now", 10) > 75:
        triggers.append("空气PM2.5污染超标")
    # 其它原有trigger判据可继续补充……
    return triggers

def rule_risk_engine(cat_obj_stats, feedback_dict):
    """
    规则流计算，返回规则分（0-100），等级，triggers（list），分项详细risk字典
    """
    risks = compute_single_risks(cat_obj_stats, feedback_dict)
    triggers = compute_triggers(cat_obj_stats, feedback_dict)
    raw_score = sum([v for v in risks.values() if v > 0])
    rule_score = min(int(float(raw_score) * 10), 100)
    level = score_level(rule_score)
    return rule_score, level, triggers, risks

def health_summary_pipeline(cat_obj_stats, feedback_dict, ml_model=None, ml_feature_keys=None):
    """
    融合规则/模型分，输出三级结构和详细解释，首页/详情/接口/日志全复用
    """
    report = health_report_template()
    rule_score, rule_level, rule_trigger, rule_risks = rule_risk_engine(cat_obj_stats, feedback_dict)
    report['rule_score'] = rule_score
    # ML模型分融合（如暂不接模型直接忽略即可）
    ml_score, ml_main_factors = None, []
    if ml_model is not None and ml_feature_keys is not None:
        fea_arr = [cat_obj_stats.get(k, 0.0) for k in ml_feature_keys]
        try:
            ml_score = ml_model.predict_proba([fea_arr])[0][1] * 100
        except:
            ml_score = None
        ml_main_factors = []  # 若已有shap/explain则可补充
        report['ml_score'] = round(ml_score, 2) if ml_score else None
    # 规则与ml分融合
    if ml_score is not None:
        score = (0.6 * ml_score + 0.4 * rule_score)
    else:
        score = rule_score
    level = score_level(score)
    triggers = rule_trigger + ml_main_factors
    report.update({
        "score": round(score, 2),
        "score_level": level,
        "main_triggers": triggers[:2],
        "all_triggers": triggers,
        "raw_risk_dict": rule_risks,
        "suggest": gen_suggest(level, triggers)
    })
    return report


def compute_objective_risks(cat_obj_stats):
    """
    包含体重/进食/饮水/排泄/心率HR/HRV等：肥胖/甲亢/肾病/肿瘤/脂肪肝/消瘦/肠炎/糖尿病/口腔炎/脱水/便秘/下尿路/结石/心脏病/应激炎症等
    """
    risks = {
        "肥胖": 0.0, "甲亢": 0.0, "肾病": 0.0, "肿瘤": 0.0,
        "脂肪肝": 0.0, "消瘦": 0.0, "肠炎": 0.0, "糖尿病": 0.0, "口腔炎": 0.0,
        "脱水": 0.0, "便秘": 0.0, "下尿路/膀胱炎": 0.0, "结石/尿闭": 0.0,
        "心脏病": 0.0, "急性应激/疼痛/炎症": 0.0
    }
    w = cat_obj_stats
    t = default_threshold

    # ==== 体重判据 ====
    if w["weight_now"] / w["ref_weight"] > 1 + t["weight_obese_pct"]:
        risks["肥胖"] += 1.0
    if w["weight_now"] / w["ref_weight"] < 1 + t["weight_thin_pct"]:
        risks["消瘦"] += 1.0
    if w.get("weight_trend_90", 0) < t["weight_hyperthy_90"]:
        risks["甲亢"] += 0.7
    if w.get("weight_trend_180", 0) < t["weight_ckd_loss_180"] and w.get("water_per_kg", 0) > t["water_per_kg"]:
        risks["肾病"] += 0.9
    if w.get("weight_trend_60", 0) < t["weight_diabetes_60"] and w.get("water_per_kg", 0) > t["water_per_kg"]:
        risks["糖尿病"] += 0.8
    if w["weight_now"] / w["ref_weight"] > 1 + t["weight_obese_pct"] and w.get("weight_trend_14", 0) < t["weight_fattyliver_loss_pct"]:
        risks["脂肪肝"] += 1.0
    if w.get("weight_trend_30", 0) < t["weight_tumor_30"]:
        risks["肿瘤"] += 0.8

    # ==== 进食/食欲判据 ====
    food_loss = w.get("food_trend_3", 0)
    food_now = w.get("food_now", 0)
    food_ref = w.get("food_ref", 0)
    noeat_days = w.get("food_noeat_days", 0)

    if noeat_days >= t.get("food_noeat_days", 2):
        risks["脂肪肝"] += 1.0
        risks["口腔炎"] += 0.7
        risks["肠炎"] += 0.6
        risks["肿瘤"] += 0.4

    if food_loss < t["food_trend_loss"]:
        risks["肠炎"] += 0.5
        risks["脂肪肝"] += 0.4
        risks["口腔炎"] += 0.3

    food_rise = w.get("food_trend_14", 0)
    if food_rise > t.get("food_trend_rise", 0.15) and w.get("weight_trend_30", 0) < t["weight_hyperthy_90"]:
        risks["甲亢"] += 1.0
        risks["糖尿病"] += 0.8

    mfeed = w.get("manual_feed_amount", 0)
    mfeed_flag = w.get("manual_feed", False)
    auto_food_recent = w.get("food_now", 0)
    total_food = auto_food_recent + (mfeed if mfeed_flag else 0)
    if food_loss < t["food_trend_loss"]:
        min_food_alarm = (food_ref or 1) * 0.8
        if total_food > min_food_alarm:
            risks["脂肪肝"] = 0.0
            risks["口腔炎"] = 0.0
            risks["肠炎"] = 0.0

    # ==== 饮水相关AI健康判据 ====
    water_now = w.get("water_now", 0)
    weight_now = w.get("weight_now", 1)
    water_per_kg = w.get("water_per_kg", water_now / weight_now if weight_now else 0.0)

    if water_per_kg > 80:
        risks["肾病"] += 0.6
        risks["糖尿病"] += 0.6
        risks["甲亢"] += 0.4
    if water_per_kg > 100:
        risks["肾病"] += 0.8
        risks["糖尿病"] += 0.8
    if (water_per_kg > 80) and (w.get("weight_trend_90", 0) < -0.08):
        risks["肾病"] += 0.5
        risks["糖尿病"] += 0.5
        risks["甲亢"] += 0.4
    if water_per_kg < 40:
        risks["脱水"] += 1.0

    w7 = w.get("water_trend_7", None)
    if w7 is not None and w7 > 0.2:
        risks["肾病"] += 0.3
        risks["糖尿病"] += 0.3

    # ==== 排泄（便/尿混合）异常判据 ====
    exc_cnt = w.get("excretion_count", 0)
    exc_vol = w.get("excretion_vol", 0)
    exc_mean = w.get("excretion_mean_w7", 1)

    if exc_cnt > 4:
        risks["腹泻"] += 0.7
        risks["肠炎"] += 0.6
        risks["下尿路/膀胱炎"] += 0.5
    if exc_cnt < 1:
        risks["便秘"] += 1.0
        risks["脱水"] += 0.7
        risks["结石/尿闭"] += 0.5
    if exc_vol < exc_mean * 0.5 and exc_cnt > 0:
        risks["结石/尿闭"] += 0.7
        risks["便秘"] += 0.6
    if exc_vol > exc_mean * 1.3 and exc_cnt > 2:
        risks["腹泻"] += 0.8
        risks["肠炎"] += 0.7

    # ==== 心率/HRV 判据 ====
    hr = w.get("hr_now", 0)
    hrw7 = w.get("hr_mean_w7", hr)
    hrv = w.get("hrv_now", 60)
    hrvw7 = w.get("hrv_mean_w7", hrv)
    # 持续高HR
    if hr > 200:
        risks["心脏病"] += 1.0
        risks["急性应激/疼痛/炎症"] += 0.8
    # 持续低HR
    if hr < 100:
        risks["心脏病"] += 0.8
    # HRV低
    if hrv < 35:
        risks["心脏病"] += 0.9
        risks["急性应激/疼痛/炎症"] += 1.0
    if hrw7 > 180:
        risks["心脏病"] += 0.7
    if abs(hr - hrw7) / (hrw7 + 0.01) > 0.3 and hr != 0:
        risks["急性应激/疼痛/炎症"] += 0.8

    return {k: round(v,2) for k, v in risks.items()}

def compute_excretion_risks(cat_obj_stats, feedback_dict):
    risks = {
        "腹泻": 0.0, "便秘": 0.0, "下尿路/膀胱炎": 0.0,
        "肾病": 0.0, "肠炎": 0.0, "结石/尿闭": 0.0, "脱水": 0.0
    }
    if feedback_dict.get("便稀", False):
        risks["腹泻"] += 1.0
        risks["肠炎"] += 0.6
    if feedback_dict.get("便硬", False):
        risks["便秘"] += 1.0
        risks["脱水"] += 0.8
    if feedback_dict.get("少量多次", False):
        risks["下尿路/膀胱炎"] += 1.0
        risks["结石/尿闭"] += 0.8
    if feedback_dict.get("黄", False):
        risks["肾病"] += 0.5
    if feedback_dict.get("血色", False):
        risks["下尿路/膀胱炎"] += 1.0
        risks["肠炎"] += 0.5
    return {k: round(v,2) for k, v in risks.items()}

def combine_with_subjective(risks, feedback_dict):
    risks = risks.copy()
    for symptom, on in feedback_dict.items():
        if on and symptom in symptom_disease_weights:
            for disease, w in symptom_disease_weights[symptom].items():
                if disease in risks:
                    risks[disease] *= w
                else:
                    risks[disease] = w
    return risks

def health_risk_pipeline(cat_obj_stats, feedback_dict):
    risks = compute_objective_risks(cat_obj_stats)
    risks = combine_with_subjective(risks, feedback_dict)
    exc_risks = compute_excretion_risks(cat_obj_stats, feedback_dict)
    for k, v in exc_risks.items():
        if k in risks:
            risks[k] += v
        else:
            risks[k] = v
    sorted_risks = sorted(risks.items(), key=lambda x: -x[1])
    return sorted_risks

def compute_env_risks(w):
    """
    输入w为特征dict，需含 temp_now/humi_now/pm25_now/co2_now 各参数
    返回带环境疾病映射打分的dict
    """
    t = default_env_threshold
    risks = {
        "环境应激/低温/热射病": 0.0,
        "慢性呼吸道/皮肤炎": 0.0,
        "哮喘": 0.0,
        "免疫抑制": 0.0,
        "精神不佳/食欲减退": 0.0,
        "昏迷/猝死高危": 0.0,
        "感冒": 0.0,
        "热射病": 0.0
    }
    temp = w.get("temp_now", 24)
    humi = w.get("humi_now", 50)
    pm25 = w.get("pm25_now", 20)
    co2 = w.get("co2_now", 500)

    # 温度
    if not (t["temp_min"] <= temp <= t["temp_max"]):
        risks['环境应激/低温/热射病'] += 1.0
        if temp < t["temp_min"] + 1:
            risks['感冒'] += 0.5
        if temp > t["temp_max"] + 3:
            risks['热射病'] += 1.0

    # 湿度
    if not (t["humi_min"] <= humi <= t["humi_max"]):
        risks['慢性呼吸道/皮肤炎'] += 0.8

    # pm2.5
    if pm25 > t["pm25_warn"]:
        risks['哮喘'] += 1.0
        risks['慢性呼吸道/皮肤炎'] += 0.8
    if pm25 > t["pm25_danger"]:
        risks['哮喘'] += 1.0
        risks['免疫抑制'] += 0.6

    # CO2
    if co2 > t["co2_warn"]:
        risks['精神不佳/食欲减退'] += 1.0
    if co2 > t["co2_danger"]:
        risks['昏迷/猝死高危'] += 1.0
    return {k: round(v,2) for k, v in risks.items()}