import numpy as np

def calc_sliding_stats(df, window=7):
    for col in ["weight", "food", "water", "hr", "hrv", "excretion"]:
        df[f"{col}_mean_w{window}"] = df[col].rolling(window, min_periods=1).mean()
        df[f"{col}_var_w{window}"] = df[col].rolling(window, min_periods=1).std()
    return df

def trend_of_period(col, df, days):
    vals = df[col].values[-days:]
    if len(vals) < 2 or np.all(np.isnan(vals)):
        return 0.0
    vals = np.nan_to_num(vals)
    x = np.arange(len(vals))
    return np.polyfit(x, vals, 1)[0]

def _clip_extreme(vals, k=2.0):
    """中位数±k*std范围外的异常值改为中位数"""
    arr = np.array(vals)
    median = np.median(arr)
    std = np.std(arr)
    arr[(arr > median + k * std) | (arr < median - k * std)] = median
    return arr

def calc_env_stats(df, window=7):
    for col in ["temp", "humi", "pm25", "co2"]:
        v = df[col].rolling(window, min_periods=1).mean().fillna(method="bfill")
        df[f"{col}_mean_w{window}"] = v

        # 去极值
        arr = _clip_extreme(df[col].values)
        df[f"{col}_clip"] = arr
    return df

def recent_env_snapshot(df):
    """返回必要环境特征：滑动均值、去异常最新值"""
    cols = ["temp", "humi", "pm25", "co2"]
    res = {}
    for col in cols:
        # 去极值
        arr = _clip_extreme(df[col].values)
        res[f"{col}_now"] = float(arr[-1]) if len(arr) else 0.0
        # 滑动均值
        if len(df) >= 7:
            res[f"{col}_mean7"] = np.mean(arr[-7:])
        else:
            res[f"{col}_mean7"] = np.mean(arr)

def recent_trends(df):
    res = {}
    periods = [3, 7, 14, 30, 60, 90, 180]
    for col in ["weight", "food", "water", "hr", "hrv", "excretion"]:
        for p in periods:
            if len(df) >= p:
                res[f"{col}_trend_{p}"] = trend_of_period(col, df, p)
    # 当前采集最后一天的“体重/进食/饮水/心率/HRV/排泄总量”
    for col in ["weight", "food", "water", "hr", "hrv", "excretion"]:
        res[f"{col}_now"] = float(df[col].values[-1]) if len(df) > 0 else 0.0

    # 排泄次数（一天内cat box记录数）
    # 假定本地df有'box_count'列为如厕行为次数
    res["excretion_count"] = int(df["box_count"].values[-1]) if "box_count" in df else 0

    # 排泄量
    res["excretion_vol"] = float(df["excretion"].values[-1]) if "excretion" in df else 0.0

    # 排泄7天均值
    if "excretion" in df:
        res["excretion_mean_w7"] = df["excretion"].rolling(7, min_periods=1).mean().values[-1]
    else:
        res["excretion_mean_w7"] = 0.0

    # 其它核心字段保持不变
    # 连续拒食天数逻辑保留（如前）
    thresh = 10
    food_arr = df["food"].values if "food" in df else []
    cnt = 0
    for v in reversed(food_arr):
        if v < thresh:
            cnt += 1
        else:
            break
    res["food_noeat_days"] = cnt
    # 饮水配比
    if 'water' in df and 'weight' in df and len(df) > 0:
        res["water_per_kg"] = float(df["water"].values[-1]) / float(df["weight"].values[-1]) if float(df["weight"].values[-1]) > 0 else 0.0
    else:
        res["water_per_kg"] = 0.0
    return res