import pandas as pd

class TraitLib:
    def __init__(self, ref_path="体重参考库中国国情.txt"):
        self.trait_df = pd.read_csv(ref_path)
    
    def ref_weight(self, breed, sex, age_days, fallback_sex="F"):
        """
        查标准体重区间。支持兜底和自动找最接近的年龄节点。
        """
        df = self.trait_df

        # 处理成年档、字符串与float混杂
        try:
            age_days_float = float(age_days)
        except:
            if isinstance(age_days, str) and age_days.isdigit():
                age_days_float = float(age_days)
            else:
                age_days_float = 365 * 2  # 默认2岁成年

        # 步骤1：先精准匹配品种性别
        sub = df[(df.breed == breed) & (df.sex == sex)]
        # 优先成年档
        if (not sub.empty) and (sub.age_days.astype(str) == "adult_stable").any():
            sub_stable = sub[sub.age_days.astype(str) == "adult_stable"]
            if not sub_stable.empty:
                row = sub_stable.iloc[0]
                return float(row.weight_min_g), float(row.weight_max_g)
        # 没成年档，找最近年龄节点
        if not sub.empty:
            sub = sub[sub.age_days.astype(str) != "adult_stable"]
            if not sub.empty:
                sub = sub.copy()
                sub["age_days_num"] = sub.age_days.astype(float)
                idx = (sub.age_days_num - age_days_float).abs().idxmin()
                row = sub.loc[idx]
                return float(row.weight_min_g), float(row.weight_max_g)
        # 步骤2：允许性别兜底
        if fallback_sex and sex != fallback_sex:
            return self.ref_weight(breed, fallback_sex, age_days, fallback_sex=None)
        # 步骤3：品种找不到，用家猫/中华田园猫
        sub = df[df.breed.str.contains("Domestic|中华", na=False, regex=True)]
        if not sub.empty:
            try:
                row = sub.iloc[0]
                return float(row.weight_min_g), float(row.weight_max_g)
            except Exception:
                pass
        # 全部无→硬编码兜底
        return 2500, 4000  # g

    # == 可扩展更多 trait 查表接口 ==