# src/ai/model_config.py

default_weights = {
    "weight": 0.2,
    "food": 0.18,
    "water": 0.15,
    "stool": 0.12,
    "hr": 0.10,
    "hrv": 0.10,
    "env": 0.08,
    "feedback": 0.07
}

# 主观症状-疾病相关性权重
symptom_disease_weights = {
    "咳嗽": {"甲亢": 1.3, "呼吸道": 1.4},
    "呕吐": {"肾病": 1.2, "肠炎": 1.2, "口腔炎": 1.1},
    "腹泻": {"肠炎": 1.3, "消瘦": 1.1},
    "食欲减退": {"肾病": 1.2, "肿瘤": 1.2, "口腔炎": 1.3},
    # 更多可以持续补充
}

default_threshold = {
    "weight_obese_pct": 0.20,   # 肥胖判定
    "weight_thin_pct": -0.15,   # 消瘦判定
    "weight_fattyliver_loss_pct": -0.08, # 脂肪肝快速体重下降
    "weight_ckd_loss_180": -0.10, # CKD风险半年体重下降
    "weight_hyperthy_90": -0.10,  # 甲亢90天体重下降
    "weight_diabetes_60": -0.07,  # 糖尿病典型趋势
    "weight_tumor_30": -0.15,     # 肿瘤30天
    "water_per_kg": 80,        # 饮水量标准
    "food_trend_pos": 0.15,
    "food_trend_neg": -0.15
}
default_env_threshold = {
    "temp_min": 19,
    "temp_max": 27,
    "humi_min": 40,
    "humi_max": 60,
    "pm25_warn": 75,
    "pm25_danger": 150,
    "co2_warn": 1200,
    "co2_danger": 2000,
}