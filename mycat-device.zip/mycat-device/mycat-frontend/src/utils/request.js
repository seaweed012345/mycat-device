// src/utils/request.js
import axios from 'axios'

const service = axios.create({
  baseURL: 'http://localhost:8001/api/datacenter', // 改成你实际后端地址
  timeout: 8001
})

export default service