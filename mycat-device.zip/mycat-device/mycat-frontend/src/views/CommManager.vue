<template>
  <div style="padding: 0;">
    <h2>通讯管理模块</h2>
    <!-- 下发任务配置表单 -->
    <el-form :model="taskForm" ref="taskFormRef" label-width="100px" style="max-width:600px;">
      <el-form-item label="任务名称">
        <el-input v-model="taskForm.name" />
      </el-form-item>
      <el-form-item label="时间类型">
        <el-select v-model="taskForm.schedule_type">
          <el-option label="定时" value="timed" />
          <el-option label="手动" value="manual" />
        </el-select>
      </el-form-item>
      <el-form-item label="定时表达式">
        <el-input v-model="taskForm.cron_expr" placeholder="如0 1 * * *" />
      </el-form-item>
      <el-form-item label="目标设备MAC">
        <el-input v-model="deviceInput" placeholder="可用英文逗号分隔多个mac" />
      </el-form-item>
      <el-form-item>
        <el-button @click="handleSubmitTask" type="primary">保存任务</el-button>
        <el-button @click="resetTask" type="info">重置</el-button>
      </el-form-item>
    </el-form>

    <!-- 当前任务列表 -->
    <h3 style="margin-top:40px;">下发任务列表</h3>
    <el-table :data="tasks" border style="width: 100%;margin-bottom:32px;">
      <el-table-column prop="id" label="ID" width="60" fixed />
      <el-table-column prop="name" label="名称" />
      <el-table-column prop="schedule_type" label="类型" />
      <el-table-column prop="cron_expr" label="Cron表达式" />
      <el-table-column prop="target_devices" label="目标设备" :formatter="devsFmt" />
      <el-table-column prop="enabled" label="启用" :formatter="enabledFmt" width="60"/>
      <el-table-column label="操作" width="160">
        <template #default="scope">
          <el-button size="small" @click="editTask(scope.row)">编辑</el-button>
          <el-popconfirm title="确定删除?" @confirm="deleteTask(scope.row.id)">
            <template #reference>
              <el-button size="small" type="danger">删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <!-- 手动下发 -->
    <h3>手动下发测试</h3>
    <el-form :model="manualForm" label-width="120px" style="max-width:550px;">
      <el-form-item label="任务ID">
        <el-input v-model="manualForm.task_id" />
      </el-form-item>
      <el-form-item label="设备MAC">
        <el-input v-model="manualForm.device_mac" />
      </el-form-item>
      <el-form-item label="下发内容(JSON)">
        <el-input v-model="manualForm.payload" placeholder='{"key":"value"}' />
      </el-form-item>
      <el-form-item>
        <el-button @click="manualDownlink" type="primary">立即下发</el-button>
      </el-form-item>
    </el-form>

    <!-- 日志与状态区 -->
    <div style="display:flex;gap:40px;margin-top:32px;">
      <div style="flex:2">
        <h3>下发日志</h3>
        <el-table :data="logs" style="width:100%" max-height="320px" border size="small">
          <el-table-column prop="sent_time" label="时间" width="160"/>
          <el-table-column prop="task_id" label="任务ID" width="70" />
          <el-table-column prop="device_mac" label="设备" />
          <el-table-column prop="status" label="状态" width="80">
            <template #default="scope">
              <el-tag :type="scope.row.status==='success'?'success':'danger'">{{scope.row.status}}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="payload" label="下发内容" />
          <el-table-column prop="response" label="回包" width="120"/>
          <el-table-column prop="error" label="错误" width="120"/>
        </el-table>
      </div>
      <div style="flex:1;">
        <h3>设备通讯状态</h3>
        <el-table :data="devices" style="width:100%" max-height="320px" size="small" border>
          <el-table-column prop="device_mac" label="MAC"/>
          <el-table-column prop="online" label="在线" width="60">
            <template #default="scope">
              <el-tag :type="scope.row.online?'success':'danger'">{{scope.row.online?"在线":"离线"}}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="last_online" label="最后上线" width="120"/>
          <el-table-column prop="downlink_count" label="累计下发" width="60"/>
          <el-table-column prop="failure_count" label="失败" width="60"/>
        </el-table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const API_BASE = 'http://localhost:8001'

const taskForm = ref({
  name: '',
  schedule_type: 'timed',
  cron_expr: '',
  target_devices: []
})
const deviceInput = ref('')
const manualForm = ref({
  task_id: '',
  device_mac: '',
  payload: ''
})

const tasks = ref([])
const logs = ref([])
const devices = ref([])

function devsFmt(row) {
  if (!row.target_devices) return '-'
  try {
    return Array.isArray(row.target_devices)
      ? row.target_devices.join(' , ')
      : JSON.parse(row.target_devices).join(' , ')
  } catch { return row.target_devices }
}
function enabledFmt(row) {
  return row.enabled ? "是" : "否"
}

function loadTasks() {
  fetch(`${API_BASE}/api/comm/tasks`).then(r=>r.json()).then(d=>tasks.value = d)
}
function loadLogs() {
  fetch(`${API_BASE}/api/comm/logs`).then(r=>r.json()).then(d=>{
    logs.value = d.map(i=>({
      ...i,
      sent_time:i.sent_time?fmtTime(i.sent_time):''
    }))
  })
}
function loadDevices() {
  fetch(`${API_BASE}/api/comm/device_status`).then(r=>r.json()).then(d=>{
    devices.value = d.map(i=>({...i,last_online:i.last_online?fmtTime(i.last_online):''}))
  })
}

function handleSubmitTask() {
  if (!taskForm.value.name) return ElMessage.warning('请填写任务名称')
  taskForm.value.target_devices = deviceInput.value.split(',').map(s=>s.trim()).filter(Boolean)
  fetch(`${API_BASE}/api/comm/tasks`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(taskForm.value)
  }).then(r=>r.json()).then(d=>{
    ElMessage.success('保存成功')
    loadTasks()
    resetTask()
  })
}
function resetTask() {
  taskForm.value = {name:'', schedule_type: 'timed', cron_expr:'', target_devices: []}
  deviceInput.value = ''
}
function deleteTask(id) {
  ElMessageBox.confirm('确定删除该任务？').then(()=>{
    fetch(`${API_BASE}/api/comm/tasks/` + id, {method:'DELETE'})
      .then(r=>r.json()).then(()=>{
        ElMessage.success('删除成功')
        loadTasks()
      })
  })
}
function editTask(row) {
  taskForm.value = {...row}
  deviceInput.value = devsFmt(row)
}

function manualDownlink() {
  if (!manualForm.value.task_id || !manualForm.value.device_mac || !manualForm.value.payload) {
    ElMessage.warning('请填写完整')
    return
  }
  let pload
  try {
    pload = JSON.parse(manualForm.value.payload)
  } catch {
    ElMessage.warning('下发内容必须为合法JSON')
    return
  }
  fetch(`${API_BASE}/api/comm/manual_downlink`, {
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({
      task_id:manualForm.value.task_id,
      device_mac:manualForm.value.device_mac.trim(),
      payload:pload
    })
  }).then(r=>r.json()).then(d=>{
    ElMessage.success('已下发，请关注日志')
    loadLogs()
  })
}

function fmtTime(tstr) {
  if (!tstr) return ''
  const d = new Date(tstr)
  return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()} ${d.getHours().toString().padStart(2,'0')}:${d.getMinutes().toString().padStart(2,'0')}:${d.getSeconds().toString().padStart(2,'0')}`
}

onMounted(()=>{
  loadTasks(); loadLogs(); loadDevices()
  setInterval(()=>{
    loadLogs(); loadDevices()
  }, 15000)
})
</script>

<style scoped>
.comm-manager-root {
  color: #111 !important;
  font-weight: 500;
}
.comm-manager-root .el-table,
.comm-manager-root .el-table th,
.comm-manager-root .el-table td,
.comm-manager-root .el-form-item__label,
.comm-manager-root .el-input__inner {
  color: #111 !important;
}
</style>