<template>
  <div style="max-width:100%;margin:0;padding:8px 0 0 0;">
    <h2>健康评测管理面板</h2>
    <!-- ========== 时间段选择 ========== -->
    <div style="margin-bottom:20px;">
      <label style="font-weight:bold;">➤ 评估评分计算时间段选择：</label>
      <select v-model="evalPeriod" style="margin-right:10px;">
        <option value="23-0">23-0点</option>
        <option value="10-11">10-11点</option>
        <option value="0-1">0-1点</option>
        <!-- 可扩展 -->
      </select>
      <button @click="saveEvalPeriod">保存设置</button>
      <span v-if="saveMsg" style="color:green;margin-left:16px;">{{saveMsg}}</span>
    </div>
    <!-- ========== 搜索部分 ========== -->
    <div style="margin-bottom:10px;">
      搜索:
      <input v-model="search" placeholder="mac/日期/分级/品种任意关键字..."/>
      <button @click="reload">搜索</button>
    </div>
    <!-- ========== 健康分表格 ========== -->
    <table border="1" cellpadding="6" cellspacing="0" width="100%">
      <thead style="background:#f0f0f0;">
        <tr>
          <th style="min-width:230px;">mac</th>
          <th style="min-width:140px;">品种</th>
          <th style="min-width:40px;">性别</th>
          <th style="min-width:200px;">评估时间</th>
          <th style="min-width:80px;">分数</th>
          <th style="min-width:80px;">分级</th>
          <th style="min-width:410px;">主解释</th>
          <th style="min-width:120px;">操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in reports" :key="item.report_id">
          <td>{{item.mac}}</td>
          <td>{{item.breed}}</td>
          <td>{{item.sex}}</td>
          <td>{{item.analyze_time}}</td>
          <td>{{item.score}}</td>
          <td>{{item.score_level}}</td>
          <td>{{item.main_triggers?.join('、')}}</td>
          <td>
            <button @click="showDetail(item)">详情</button>
            <button @click="rerun(item)">再分析</button>
          </td>
        </tr>
      </tbody>
      <tfoot v-if="reports.length===0"><tr><td colspan="8" style="text-align:center;">暂无记录</td></tr></tfoot>
    </table>

    <!-- ========== 详情弹窗 ========== -->
    <div v-if="detailVisible" style="position:fixed;left:0;top:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);z-index:99;">
      <div style="background:white;max-width:700px;margin:50px auto;padding:32px;box-shadow:0 5px 24px #0003;position:relative;">
        <button style="position:absolute;right:16px;top:16px;" @click="detailVisible=false">关闭</button>
        <h3>分析详情 {{detailData.report_id}}</h3>
        <div>分数: {{detailData.score}} 分级: {{detailData.score_level}}</div>
        <div>分析时间: {{detailData.analyze_time}}</div>
        <div>主trigger: {{detailData.main_triggers?.join('、')}}</div>
        <div>全部trigger: {{detailData.all_triggers?.join('、')}}</div>
        <div>
          <b>分项打分:</b>
          <pre style="background:#eee;padding:8px;">{{ JSON.stringify(detailData.raw_risk_dict, null, 2) }}</pre>
        </div>
        <div>
          <b>原始体征参数:</b>
          <pre style="background:#eee;padding:8px;">{{ JSON.stringify(detailData.cat_obj_stats, null, 2) }}</pre>
        </div>
        <div>
          <b>用户反馈:</b>
          <pre style="background:#eee;padding:8px;">{{ JSON.stringify(detailData.feedback_dict, null, 2) }}</pre>
        </div>
        <div style="margin-top:10px;">
          <label>备注/人工说明：</label>
          <input v-model="detailData.comment" style="width:80%;"/>
          <button @click="saveComment(detailData)">保存备注</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import {ref, onMounted} from 'vue'
import axios from 'axios'

const API_BASE = 'http://localhost:8001'

const evalPeriod = ref('23-0')
const saveMsg = ref('')
const search = ref('')
const reports = ref([])
const detailVisible = ref(false)
const detailData = ref({})

onMounted(async () => {
  // 获取评估时间段
  const resp = await axios.get(`${API_BASE}/api/settings/eval_period`)
  evalPeriod.value = resp.data.eval_period
  await reload()
})

async function saveEvalPeriod() {
  await axios.post(`${API_BASE}/api/settings/eval_period`, {eval_period: evalPeriod.value})
  saveMsg.value = '已保存'
  setTimeout(()=>saveMsg.value='', 2000)
  await reload()
}

async function reload() {
  const resp = await axios.get(`${API_BASE}/api/health/report/list`, {
    params: { period: evalPeriod.value, search: search.value }
  })
  reports.value = resp.data
}

async function showDetail(item) {
  const id = item.report_id
  const resp = await axios.get(`${API_BASE}/api/health/report/detail`, {params: {report_id: id}})
  detailData.value = resp.data
  detailVisible.value = true
}
async function rerun(item) {
  const id = item.report_id
  const resp = await axios.post(`${API_BASE}/api/health/report/rerun`, {report_id:id})
  alert('已重新分析！新分数：' + resp.data.score)
  await reload()
}
async function saveComment(item) {
  await axios.post(`${API_BASE}/api/health/report/mark`, {report_id:item.report_id, mark:item.comment})
  alert('备注已保存！')
}
</script>