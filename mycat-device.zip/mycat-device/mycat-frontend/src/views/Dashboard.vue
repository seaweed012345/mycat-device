<template>
  <!-- 品牌LOGO与口号区块（可按需保留/修改） -->
  <section class="brand-section">
    <img src="/img/logo.png" class="brand-logo" alt="LOGO" />
    <div class="brand-slogan">让炬窝科技重新定义生活。</div>
    <div class="brand-sub">Juwo. Life, Redefined.</div>
  </section>
  <!-- 仪表盘三大信息板块 -->
  <section class="dashboard-cards">
    <!-- 板块一：设备在线统计 -->
    <div class="card">
      <div class="card-title">设备在线：</div>
      <div class="card-item">历史在线：10020台</div>
      <div class="card-item">昨日在线：9800台</div>
      <div class="card-item">今日在线：6654台</div>
    </div>
    <!-- 板块二：最新订单动态 -->
    <div class="card">
      <div class="card-title">最新订单：</div>
      <div class="card-item">
        1.<br>
        下单时间：2026/03/30/18:31<br>
        订单品名：现代智能款<br>
        选品规格：90*70*156cm<br>
        下单数量：1个
      </div>
      <div class="card-item">
        2.<br>
        下单时间：2026/03/30/15:21<br>
        订单品名：欧式智能款<br>
        选品规格：90*70*156cm<br>
        下单数量：1个
      </div>
    </div>
    <!-- 板块三：系统状态 -->
    <div class="card">
      <div class="card-title">系统状态：</div>
      <div class="card-item">CPU占用：81%</div>
      <div class="card-item">内存占用：54%/6G</div>
      <div class="card-item">存储占用：39%/8G</div>
      <div class="card-item">昨日流量：218Mb</div>
      <div class="card-item">上月流量：2.3GB</div>
      <div class="card-item">年消累积：548GB</div>
      <div class="card-item">当前状态：正常</div>
    </div>
  </section>
</template>

<script setup>
// 首页仪表盘无全局状态依赖——所有"主页内容"只放在这里！
// 可后期从后端API动态获取仪表卡片内容
</script>

<style scoped>
/* ==================== */
/* 品牌LOGO与口号版面  */
/* ==================== */
.brand-section {
  width: 100%;
  text-align: center;
  margin-bottom: 48px;
}
.brand-logo {
  width: 148px; /* LOGO宽 */
  height: auto;
  margin-bottom: 24px;
}
.brand-slogan {
  font-size: 2.50rem;
  color: #606468;
  letter-spacing: 6.5px;
  margin-bottom: 9px;
  font-family: "微软雅黑", "Arial", sans-serif;
}
.brand-sub {
  font-size: 1.31rem;
  color: #3991d8;
  font-weight: 500;
  letter-spacing: 2.5px;
  margin-bottom: 38px;
}

/* = 仪表盘三大信息板块排版 = */
.dashboard-cards {
  display: flex;
  justify-content: center;
  gap: 58px;
  width: 100%;
  max-width: 1660px;
}
.card {
  min-width: 275px;
  background: #fff;
  border: 2.1px solid #d0d0d0;
  border-radius: 22px;
  padding: 15px 32px 120px 32px;
  box-sizing: border-box;
  box-shadow: 0 4px 16px 0 #f1f5fa;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.card-title {
  font-size: 1.19rem;
  color: #3085d6;
  font-weight: bold;
  margin-bottom: 19px;
  letter-spacing: 1.7px;
}
.card-item {
  font-size: 1.09rem;
  color: #444;
  margin-bottom: 11px;
  word-break: break-all;
  letter-spacing: 1.3px;
}
.card-item:last-child {
  margin-bottom: 0;
}
/* ====== 响应式微调 ====== */
@media (max-width: 1200px) {
  .dashboard-cards {
    gap: 24px;
    max-width: 920px;
  }
  .card { min-width: 230px; padding: 24px 10px; }
}
@media (max-width: 800px) {
  .dashboard-cards {
    flex-direction: column;
    align-items: center;
    gap: 15px;
  }
}
</style>