<template>
  <div class="device-manager-page">
    <!-- 顶部工具栏 -->
    <div class="toolbar">
      <el-button type="primary" @click="onAdd">新增设备</el-button>
      <el-button @click="onBatchImport">批量导入</el-button>
      <el-button @click="onGroup">分组管理</el-button>
      <el-button @click="exportDevices" type="info">导出设备</el-button>
      <el-input
        v-model="keyword"
        placeholder="搜索 MAC/SN/分组/别名"
        class="toolbar-search"
        clearable
        @input="fetchDeviceList"
      />
    </div>

    <el-tabs v-model="tab" type="card">
      <!-- 设备列表Tab -->
      <el-tab-pane label="设备列表" name="device">
        <el-table
          :data="deviceList"
          border
          style="width: 100%;"
          height="500"
          :header-cell-style="{background:'#f6f7fb',fontWeight:600,fontSize:'1rem',textAlign:'center'}"
          :cell-style="{textAlign:'center'}"
          row-key="id"
        >
          <el-table-column type="selection" width="40" />
          <el-table-column prop="mac" label="MAC" width="160" />
          <el-table-column prop="sn" label="SN" width="140" />
          <el-table-column prop="alias" label="别名" width="100" />
          <el-table-column prop="group" label="分组" width="180" />
          <el-table-column prop="status" label="状态" width="80">
            <template #default="{ row }">
              <el-tag :type="row.status === '在线' ? 'success' : 'info'">{{ row.status }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="owner" label="归属用户" width="120" />
          <el-table-column prop="phone" label="联系电话" width="150" />
          <el-table-column prop="createTime" label="注册时间" width="146">
            <template #default="{ row }">
              <span class="cell-time">{{ row.createTime }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" fixed="right" width="490">
            <template #default="{ row }">
              <el-button size="small" class="op-btn" @click="onDetail(row)">详情</el-button>
              <el-button size="small" class="op-btn" type="primary" @click="onEdit(row)">编辑</el-button>
              <el-button size="small" class="op-btn" type="warning" @click="onAuth(row)">授权</el-button>
              <el-button size="small" class="op-btn" type="danger" @click="onDelete(row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>

      <!-- 其余授权、升级、分组Tab不变，略，可以复用你的原实现 -->
      <!-- ... -->
    </el-tabs>

    <!-- 新增设备弹窗 -->
    <el-dialog v-model="addDialogVisible" title="新增设备" width="430px" @close="resetNewDevice">
      <el-form :model="newDevice" label-width="90px" :rules="rules" ref="formRef">
        <el-form-item label="MAC" prop="mac">
          <el-input v-model="newDevice.mac" placeholder="请填写MAC" />
        </el-form-item>
        <el-form-item label="SN" prop="sn">
          <el-input v-model="newDevice.sn" placeholder="请填写SN" />
        </el-form-item>
        <el-form-item label="别名">
          <el-input v-model="newDevice.alias" placeholder="如‘客厅主机’" />
        </el-form-item>
        <el-form-item label="分组">
          <el-input v-model="newDevice.group" placeholder="分组名" />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="newDevice.status" style="width: 120px;">
            <el-option value="在线" label="在线" />
            <el-option value="离线" label="离线" />
          </el-select>
        </el-form-item>
        <el-form-item label="归属用户">
          <el-input v-model="newDevice.owner" placeholder="负责人" />
        </el-form-item>
        <el-form-item label="联系电话">
          <el-input v-model="newDevice.phone" placeholder="填写手机号" />
        </el-form-item>
        <el-form-item label="注册时间">
          <el-input v-model="newDevice.createTime" placeholder="如2026/04/04 11:00" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="addDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="addDevice">保存</el-button>
      </template>
    </el-dialog>
    <!-- 其余批量导入、分组弹窗等略，可仿照实现 -->

  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import axios from 'axios'
import { ElMessage, ElMessageBox } from 'element-plus'

// 设备主表
const deviceList = ref([])
// 查询关键词
const keyword = ref('')
// 当前tab
const tab = ref('device')

// =================== API相关 ===================
const API_BASE = 'http://localhost:8001/api/device'

// 查询设备列表
function fetchAuthList() {
  axios.get(API_BASE + '/auth').then(res => {
    authList.value = res.data
  })
}
onMounted(() => {
  fetchDeviceList()
  fetchAuthList()
})

// 用于拉取设备数据列表
function fetchDeviceList() {
  axios.get('http://localhost:8001/api/device/', { params: { keyword: keyword.value } })
    .then(res => { deviceList.value = res.data })
    .catch(err => { deviceList.value = []; console.error('设备数据获取失败', err) })
}

onMounted(fetchDeviceList)

function saveAuth() {
  if (!addAuthForm.value.deviceMac || !addAuthForm.value.username || !addAuthForm.value.type) {
    ElMessage.warning('请填写完整信息')
    return
  }
  axios.post(API_BASE + '/auth', addAuthForm.value)
    .then(() => {
      ElMessage.success('新增授权成功')
      addAuthDialogVisible.value = false
      fetchAuthList()
    })
}

function revokeAuth(row) {
  axios.delete(API_BASE + `/auth/${row.id}`)
    .then(() => {
      ElMessage.success('已回收')
      fetchAuthList()
    })
}


// 新增设备
const addDialogVisible = ref(false)
const newDevice = reactive({
  mac: '', sn: '', alias: '', group: '', status: '在线',
  owner: '', phone: '', createTime: ''
})
const formRef = ref(null)
const rules = {
  mac: [{ required: true, message: 'MAC必填', trigger: 'blur' }],
  sn: [{ required: true, message: 'SN必填', trigger: 'blur' }],
}
function onAdd() {
  Object.assign(newDevice, { mac:'', sn:'', alias:'', group:'', status:'在线', owner:'', phone:'', createTime:''})
  addDialogVisible.value = true
}

function importDevices() {
  if (batchDevices.value.length === 0) {
    ElMessage.warning('请先上传csv文件')
    return
  }
  importing.value = true
  axios.post(API_BASE + '/batch', { devices: batchDevices.value })
    .then(res => {
      ElMessage.success(res.data.msg || '批量导入完成')
      fetchDeviceList()
      batchDialogVisible.value = false
      importing.value = false
      batchDevices.value = []
    })
    .catch(err => {
      ElMessage.error('批量导入失败')
      importing.value = false
    })
}

function addDevice() {
  formRef.value.validate(valid => {
    if (!valid) return
    axios.post(API_BASE + '/', newDevice)
      .then(() => {
        ElMessage.success('新增成功')
        addDialogVisible.value = false
        fetchDeviceList()
      })
      .catch(e => ElMessage.error(e.response?.data?.error ?? '接口异常'))
  })
}
function resetNewDevice() {
  Object.assign(newDevice, { mac:'', sn:'', alias:'', group:'', status:'在线', owner:'', phone:'', createTime:''})
}

// 删除设备
function onDelete(row) {
  ElMessageBox.confirm(
    `确定要删除设备 [${row.alias}] (MAC: ${row.mac}) 吗？`,
    '确认删除',
    { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' }
  ).then(() => {
    axios.delete(`${API_BASE}/${row.id}`).then(() => {
      ElMessage.success('设备已删除！')
      fetchDeviceList()
    })
  })
}

// 详情演示（可根据需要拓展为抽屉/弹窗）
function onDetail(row) {
  ElMessageBox.alert(
    `设备详情：\nMAC：${row.mac}\nSN：${row.sn}\n归属：${row.owner}\n电话：${row.phone}`,
    '设备详情',
    { confirmButtonText: '关闭' }
  )
}

// 编辑、授权、批量导入、分组管理等功能同理拓展 —— 原有代码保留调整为API方式即可

onMounted(fetchDeviceList)
</script>

<style scoped>
.device-manager-page {
  width: 100%;
  max-width: 1760px;
  margin: 0 auto;
  padding-top: 18px;
}
.toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}
.toolbar-search {
  width: 220px;
  margin-left: auto;
}
.cell-time {
  color: #888;
  font-size: 12px;
}
.tab-placeholder {
  text-align: center;
  color: #aaa;
  margin: 48px 0 0 0;
  font-size: 1.15rem;
}
:deep(.op-btn + .op-btn) { margin-left: 8px; }
</style>