<template>
  <div class="stats-dashboard-root">
    <h2>运行统计</h2>
    <div style="display:flex;gap:36px;margin:15px 0;">
      <el-card v-for="card in cards" class="stat-card" :key="card.title">
        <div>
          <div style="font-size:1.3em;margin-bottom:6px;">{{card.title}}</div>
          <div style="font-size:2.1em;font-weight:bold">{{card.value}}</div>
          <div style="color:#6e6e6e">{{card.desc}}</div>
        </div>
      </el-card>
    </div>
    <el-tabs>
      <el-tab-pane label="服务器详情">
        <el-table :data="serverInfo" border style="margin-top:18px">
          <el-table-column prop="k" label="指标"/>
          <el-table-column prop="v" label="值"/>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="流量趋势">
        <!-- 这里可用Echarts加载趋势图，示例只占位 -->
        <div style="height:300px;display:flex;align-items:center;justify-content:center;background:#f4f7fa;">
          <span>流量趋势图/历史曲线（待接入echarts）</span>
        </div>
      </el-tab-pane>
      <el-tab-pane label="异常/操作日志">
        <el-table :data="logs" border>
          <el-table-column prop="time" label="时间" width="150"/>
          <el-table-column prop="type" label="类型" width="80"/>
          <el-table-column prop="msg" label="内容"/>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="进程健康">
        <el-table :data="processes" border>
          <el-table-column prop="name" label="进程名"/>
          <el-table-column prop="pid" label="PID" width="80"/>
          <el-table-column prop="status" label="状态"/>
          <el-table-column prop="mem" label="内存占用"/>
        </el-table>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup>
import { ref } from 'vue'
const cards = [
  { title: 'CPU占用', value: '82%', desc: '负载：正常' },
  { title: '内存占用', value: '65%', desc: '6GB/8GB' },
  { title: '设备在线', value: '6500台', desc: '总注册10k' }
]
const serverInfo = ref([
  { k:'CPU核数', v:8 }, {k:'物理内存',v:'8GB'}, {k:'带宽',v:'1000Mbps'}, {k:'系统',v:'Ubuntu 22.04'}
])
const logs = ref([
    { time: '2026-04-01 13:50', type: '操作', msg: '服务重启' },
    { time: '2026-04-01 12:16', type: '异常', msg: 'CPU突增' }
])
const processes = ref([
    { name: 'mycat-server', pid: 2178, status: 'running', mem: '79M' },
    { name: 'mqtt-agent', pid: 2179, status: 'sleeping', mem: '12M' }
])
</script>
<style scoped>
.stats-dashboard-root { padding:30px 30px 0 20px; }
.stat-card { min-width:190px; min-height:100px;}
</style>