<template>
  <div class="main">
    <!-- 左侧LOGO与品牌区 -->
    <div class="left">
      <!-- 静态图片放在 public/img/logo.png 下，路径以 /img/logo.png 引用 -->
      <img src="/img/logo.png" class="logo" alt="LOGO" />
      <div class="brand-cn">炬窝科技后台管理系统</div>
      <div class="brand-en">Juwо Tech Admin Panel</div>
    </div>
    <!-- 右侧表单区 -->
    <div class="right">
      <form @submit.prevent="handleLogin">
        <div class="form-title">Login</div>
        <!-- 用户名 -->
        <label>用户名</label>
        <input
          v-model="username"
          type="text"
          placeholder="请输入用户名"
          required
        />
        <!-- 密码 -->
        <label>密码</label>
        <input
          v-model="password"
          type="password"
          placeholder="请输入密码"
          required
        />
        <!-- 验证码区域。后期可对接后端动态验证码图片 -->
        <div class="form-row captcha-row">
          <label class="captcha-label">验证码</label>
          <input
            v-model="captcha"
            type="text"
            maxlength="4"
            placeholder="验证码"
            class="captcha-input"
          />
          <img
            :src="captchaImgUrl"
            @click="loadCaptcha"
            :title="'点击刷新验证码'"
            class="captcha-img"
            style="height:30px;cursor:pointer; margin-left:7px;"
          />
        </div>
        <!-- 记住我/忘记密码 -->
        <div class="form-row remember-row">
          <label>
            <input type="checkbox" v-model="remember" />
            记住我
          </label>
          <a href="/forgot" class="forgot-link">忘记密码?</a>
        </div>
        <!-- 登录/注册按钮 -->
        <button type="submit" class="login-btn">登录</button>
        <button
          type="button"
          class="register-btn"
          @click="goRegister"
        >现在注册</button>
        <!-- 提示出错信息 -->
        <div v-if="error" class="error-msg">{{ error }}</div>
      </form>
    </div>
  </div>
</template>

<script setup>
// 登陆相关逻辑
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

// 数据
const username = ref('')
const password = ref('')
const captcha = ref('')
const remember = ref(false)
const error = ref('')
const router = useRouter()
const captchaImgUrl = ref('')
const captchaKey = ref('')

// 每次都用时间戳反缓存
function loadCaptcha() {
  captchaImgUrl.value = 'http://localhost:8001/api/captcha?' + Date.now();
  captcha.value = '';
}
onMounted(loadCaptcha)

function goRegister() {
  // 调试用
  console.log('去注册页面');
  router.push('/register');
}

function handleLogin() {
  if (!username.value || !password.value || !captcha.value) {
    error.value = '请填写完整用户名、密码与验证码'
    return
  }
  fetch('http://localhost:8001/api/user/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({
      username: username.value,
      password: password.value,
      captcha: captcha.value
    })
  }).then(async res => {
    const data = await res.json()
    if (!res.ok) {
      error.value = data.error || '登录失败'
      loadCaptcha()
      return
    }
    // ===== 关键保存权限&用户信息 =====
    localStorage.setItem('permissions', JSON.stringify(data.user.permissions))
    localStorage.setItem('currentUser', JSON.stringify(data.user))
    error.value = ''
    router.push('/dashboard')
  }).catch(() => {
    error.value = '请求失败，请重试'
    loadCaptcha()
  })
}
</script>

<style scoped>
/* ==== 全局字体背景 ==== */
body {
  background: #fff;
  margin: 0;
  font-family: '微软雅黑', 'Arial', sans-serif;
}

/* ==== 主容器布局 ==== */
.main {
  width: 1200px;      /* 容器宽度 */
  height: 100vh;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* ==== 左侧logo区 ==== */
.left {
  flex: 1 1 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.logo {
  width: 240px;
  margin: 0 0 10px 0;
}
.brand-cn {
  font-size: 2.5rem;
  color: #3582be;
  letter-spacing: 12px;
  margin: 12px 0 4px 0;
  font-weight: 500;
}
.brand-en {
  font-size: 1.35rem;
  color: #3582be;
  margin-bottom: 50px;
}

/* ==== 右侧表单区 ==== */
.right {
  flex: 1 1 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: none;
  box-shadow: none;
  border-radius: 0;
  padding: 0;
}

/* ==== 表单布局 ==== */
form {
  width: 340px;
  display: flex;
  flex-direction: column;
}
.form-title {
  text-align: center;
  font-size: 1.14rem;
  margin-bottom: 5px;
  color: #bbb;
  letter-spacing: 2px;
}
label {
  display: block;
  margin-top: 7px;
  margin-bottom: 5px;
  color: #444;
  font-size: 0.6rem;
}
.captcha-label {
  font-size: 0.7rem;
  margin-top: 0.7px;
  margin-bottom: 4px;
  color: #666;
  letter-spacing: 0.3px;
}

/* ==== 输入框 ==== */
input[type="text"],
input[type="password"] {
  width: 100%;
  box-sizing: border-box;
  padding: 5px 10px;
  border: 1px solid #d0d6e1;
  border-radius: 8px;
  font-size: 0.9rem;
  margin-bottom: 1px;
  outline: none;
  background: #f6faff;
}
input[type="text"]:focus,
input[type="password"]:focus {
  border-color: #3582be;
  background: #eaf3fc;
}

/* ==== 验证码相关 ==== */
.captcha-row {
  display: flex;
  align-items: center;
  gap: 8px;              /* 控制输入框与验证码图片间距 */
  margin-bottom: 3px;
}

.captcha-input {
  flex: 1 1 0;
  min-width: 0;
}

.captcha-img {
  height: 15px;         /* 你喜欢的小高度 */
  width: 160px;          /* 明确限制宽度，视实际图片内容定，可调 */
  object-fit: contain;  /* 保证图片等比例缩放、不拉伸 */
  border: 1px solid #eee;
  border-radius: 4px;
  cursor: pointer;
  margin-left: auto;    /* 图片自动靠最右 */
  background: #fff;
  box-sizing: border-box;
}

/* ==== 记住我 + 忘记密码 ==== */
.remember-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2px;
  margin-top: 6px;
}
.remember-row label {
  margin: 0;
  font-size: .7rem;
}
.forgot-link {
  color: #3582be;
  font-size: .7rem;
  text-decoration: none;
}
.forgot-link:hover {
  text-decoration: underline;
}

/* ==== 主按钮 ==== */
.login-btn {
  width: 100%;
  background: linear-gradient(#62a9db,#3582be);
  color: #fff;
  border: none;
  border-radius: 6px;
  padding: 8px 0;
  font-size: 1.11rem;
  font-weight: bold;
  margin: 5px 0 10px 0;
  cursor: pointer;
  letter-spacing: 2px;
}
.login-btn:hover {
  background: linear-gradient(#3e88c0,#2362a0);
}

/* ==== 注册按钮 ==== */
.register-btn {
  width: 100%;
  background: none;
  color: #3582be;
  border: 0.8px solid #3582be;
  font-size: 1.07rem;
  border-radius: 6px;
  padding: 4px 0;
  cursor: pointer;
  transition: background .2s;
  margin-bottom: 8px;
}
.register-btn:hover {
  background: #f7fbff;
}

/* ==== 错误提示 ==== */
.error-msg {
  color: #b00;
  text-align: center;
  margin: 12px 0 0 0;
  font-size: 0.95rem;
}
</style>