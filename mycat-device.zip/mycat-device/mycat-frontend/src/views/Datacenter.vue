<template>
  <div class="datacenter-page">
    <!-- 查询与筛选区 -->
    <el-row :gutter="20" class="mb-2" justify="start">
      <el-col :span="18">
        <el-select v-model="filterType" placeholder="选择查询项" class="mr-2" style="width: 140px;">
          <el-option label="MAC" value="mac" />
          <el-option label="健康值" value="health_eval" />
          <el-option label="品种" value="breed" />
          <el-option label="HR" value="hr_hrv" />
        </el-select>
        <el-input v-model="queryValue" placeholder="请输入关键字" class="mr-2" style="width: 180px;" />
        <el-button @click="onSearch" type="primary">查询</el-button>
        <el-button @click="onReset" type="default" class="mr-2">重置</el-button>
      </el-col>
    </el-row>
    <!-- 主表 -->
    <el-table
      :data="tableData"
      border
      style="width: 100%;"
      height="600"
      :header-cell-style="{background:'#f6f7fb',fontWeight:600,fontSize:'1rem',textAlign:'center'}"
      :cell-style="{textAlign:'center'}"
      @row-click="handleDetail"
      row-key="id"
    >
      <el-table-column prop="mac" label="MAC" fixed width="150" />

      <el-table-column label="进食/总余量" width="140">
        <template #default="{ row }">
          <div>
            {{ (row.in_feed || '').split('\n')[0] }}
            <div class="cell-time">{{ (row.in_feed || '').split('\n')[1] }}</div>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="饮水/总余量" width="140">
        <template #default="{ row }">
          <div>
            {{ (row.in_water || '').split('\n')[0] }}
            <div class="cell-time">{{ (row.in_water || '').split('\n')[1] }}</div>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="排泄/体重" width="140">
        <template #default="{ row }">
          <div>
            {{ (row.out_weight || '').split('\n')[0] }}
            <div class="cell-time">{{ (row.out_weight || '').split('\n')[1] }}</div>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="心率/HRV/传感器" width="170">
        <template #default="{ row }">
          <div>
            {{ (row.hr_hrv || '').split('\n')[0] }}
            <div class="cell-time">{{ (row.hr_hrv || '').split('\n')[1] }}</div>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="温/湿度" width="120">
        <template #default="{ row }">
          <div>
            {{ (row.env_temp || '').split('\n')[0] }}
            <div class="cell-time">{{ (row.env_temp || '').split('\n')[1] }}</div>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="空气质量" width="110">
        <template #default="{ row }">
          <div>
            {{ (row.env_air || '').split('\n')[0] }}
            <div class="cell-time">{{ (row.env_air || '').split('\n')[1] }}</div>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="二氧化碳含量" width="130">
        <template #default="{ row }">
          <div>
            {{ (row.env_co2 || '').split('\n')[0] }}
            <div class="cell-time">{{ (row.env_co2 || '').split('\n')[1] }}</div>
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="breed" label="品种" width="80" />
      <el-table-column prop="age" label="年龄" width="80" />
      <el-table-column prop="gender" label="性别" width="60" />
      <el-table-column prop="neutered" label="绝育" width="60" />

      <el-table-column label="健康值/评测内容" width="240">
        <template #default="{ row }">
          <div>
            {{ (row.health_eval || '').split('\n')[0] }}
            <div class="cell-time">{{ (row.health_eval || '').split('\n')[1] }}</div>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="客户反馈" width="140" show-overflow-tooltip>
        <template #default="{ row }">
          <div>
            {{ (row.feedback || '').split('\n')[0] }}
            <div class="cell-time">{{ (row.feedback || '').split('\n')[1] }}</div>
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="filter_effect" label="滤网时效" width="110" />

      <!-- 在此新增 删除按钮 -->
      <el-table-column fixed="right" label="操作" width="120">
        <template #default="scope">
          <el-button type="primary" @click.stop="showDetail(scope.row)" size="small">详情</el-button>
          <el-button type="danger" @click.stop="onDelete(scope.row)" size="small" style="margin-left: 6px;">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 详情抽屉 -->
    <el-drawer v-model="drawerVisible" size="50%">
      <h3>设备详情：{{ currentDevice?.mac }}</h3>
      <el-descriptions :column="2" size="small" border>
        <el-descriptions-item label="MAC">{{ currentDevice?.mac }}</el-descriptions-item>
        <el-descriptions-item label="品种">{{ currentDevice?.breed }}</el-descriptions-item>
        <el-descriptions-item label="年龄">{{ currentDevice?.age }}</el-descriptions-item>
        <el-descriptions-item label="性别">{{ currentDevice?.gender }}</el-descriptions-item>
        <el-descriptions-item label="进食">{{ currentDevice?.in_feed }}</el-descriptions-item>
        <el-descriptions-item label="饮水">{{ currentDevice?.in_water }}</el-descriptions-item>
        <el-descriptions-item label="排泄/体重">{{ currentDevice?.out_weight }}</el-descriptions-item>
        <el-descriptions-item label="心率/HRV">{{ currentDevice?.hr_hrv }}</el-descriptions-item>
        <el-descriptions-item label="温/湿度">{{ currentDevice?.env_temp }}</el-descriptions-item>
        <el-descriptions-item label="空气质量">{{ currentDevice?.env_air }}</el-descriptions-item>
        <el-descriptions-item label="二氧化碳">{{ currentDevice?.env_co2 }}</el-descriptions-item>
        <el-descriptions-item label="健康值/评测">{{ currentDevice?.health_eval }}</el-descriptions-item>
        <el-descriptions-item label="客户反馈">{{ currentDevice?.feedback }}</el-descriptions-item>
        <el-descriptions-item label="滤网时效">{{ currentDevice?.filter_effect }}</el-descriptions-item>
      </el-descriptions>
    </el-drawer>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { ElMessageBox, ElMessage } from 'element-plus'

const filterType = ref('mac')
const queryValue = ref('')
const tableData = ref([])
const drawerVisible = ref(false)
const currentDevice = ref(null)

// === 动态数据区 ===
const apiBase = 'http://localhost:8001/api/datacenter' // 请根据实际情况调整

const fetchList = () => {
  let params = {}
  if (filterType.value && queryValue.value) {
    params.filterType = filterType.value
    params.queryValue = queryValue.value
  }
  axios.get(apiBase, { params }).then(res => {
    // 返回值为设备数组
    tableData.value = res.data
  })
}
onMounted(fetchList)

function onSearch() {
  fetchList()
}
function onReset() {
  queryValue.value = ''
  fetchList()
}

function showDetail(row) {
  axios.get(`${apiBase}/${row.id}`).then(res => {
    currentDevice.value = res.data
    drawerVisible.value = true
  })
}

function handleDetail(row) { showDetail(row) }

function onDelete(row) {
  // row.id 必须与后端 DeviceData 主键一致
  ElMessageBox.confirm('确定删除本行数据？', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    axios.delete(`${apiBase}/${row.id}`).then(() => {
      ElMessage.success('删除成功')
      fetchList()
    })
  }).catch(() => {})
}

</script>

<style scoped>
.datacenter-page {
  width: 100%;
  max-width: 1800px;
  margin: 0 auto;
  padding-top: 12px;
}
:deep(.el-table) {
  color: #202227;
  font-size: 15px;
}
:deep(.el-table th) {
  color: #2c8388;
  font-size: 15px;
  font-weight: bold;
}
:deep(.cell-time) {
  color: #888;
  font-size: 12px;
  line-height: 1.2;
  margin-top: 2px;
}
.mb-2 { margin-bottom: 16px; }
.mr-2 { margin-right: 8px; }
</style>