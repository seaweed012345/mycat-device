<template>
  <div class="system-settings-root">
    <h2>系统设置</h2>
    <el-tabs v-model="tab">
      <el-tab-pane label="账号权限管理" name="users">
        <el-button type="primary" @click="showAddUser = true; editingUser = false;">新建账号</el-button>
        <el-table :data="users" border style="margin:16px 0">
          <el-table-column prop="username" label="用户名" width="220"/>
          <el-table-column prop="role" label="角色" width="120"/>
          <el-table-column label="权限" min-width="740">
            <template #default="scope">
              <el-tag v-for="p in modules" :key="p.key"
                :type="scope.row.permissions && scope.row.permissions.includes(p.key) ? 'success':'info'"
                style="margin:2px;">
                {{p.label}}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="180">
            <template #default="scope">
              <el-button size="small" @click="editUser(scope.row)">编辑</el-button>
              <el-button size="small" type="danger" @click="deleteUser(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="操作日志" name="logs">
        <el-table :data="logs" border>
          <el-table-column prop="time" label="时间" width="260"/>
          <el-table-column prop="user" label="账号" width="200"/>
          <el-table-column prop="action" label="操作内容" width="260"/>
        </el-table>
      </el-tab-pane>
    </el-tabs>

    <!-- 新建/编辑账号弹窗 -->
    <el-dialog v-model="showAddUser" :title="editingUser?'编辑账号':'新建账号'">
      <el-form :model="userForm" label-width="80px">
        <el-form-item label="用户名">
          <el-input v-model="userForm.username" :disabled="editingUser"/>
        </el-form-item>
        <el-form-item label="角色">
          <el-select v-model="userForm.role">
            <el-option label="管理员" value="admin"/>
            <el-option label="普通用户" value="user"/>
            <el-option label="访客仅读" value="viewer"/>
          </el-select>
        </el-form-item>
        <el-form-item label="初始密码" v-if="!editingUser">
          <el-input v-model="userForm.password"/>
        </el-form-item>
        <el-form-item label="权限分配">
          <el-checkbox-group v-model="userForm.permissions">
            <el-checkbox v-for="m in modules" :label="m.key" :key="m.key">{{m.label}}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddUser=false; editingUser=false;">取消</el-button>
        <el-button type="primary" @click="saveUser">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'

const tab = ref('users')
const showAddUser = ref(false)
const editingUser = ref(false)
const userForm = ref({
  username: '', role: 'user', password: '', permissions: ['dashboard']
})

const modules = [
  { key: 'dashboard', label: '首页总览' },
  { key: 'datacenter', label: '数据中心' },
  { key: 'device', label: '设备管理' },
  { key: 'aicloud', label: 'AI云算' },
  { key: 'comm', label: '通讯管理' },
  { key: 'wechat', label: '微信商城' },
  { key: 'system', label: '系统设置' },
  { key: 'stats', label: '运行统计' }
]

const users = ref([])
function fetchUsers() {
  axios.get('http://localhost:8001/api/users')
    .then(res => {
      users.value = (res.data || []).map(item => ({
        ...item,
        role: item.role || 'user',
        permissions: Array.isArray(item.permissions) && item.permissions.length > 0
          ? item.permissions
          : ['dashboard']
      }))
    })
    .catch(e => {
      ElMessage.error("加载用户列表失败：" + e)
      users.value = []
    })
}
onMounted(fetchUsers)
const logs = ref([])

// 编辑用户
function editUser(u) {
  editingUser.value = true
  showAddUser.value = true
  userForm.value = {
    username: u.username,
    role: u.role || 'user',
    password: '', // 编辑时不展示/不允许改密码
    permissions: Array.isArray(u.permissions) ? u.permissions : ['dashboard'],
  }
}

// 删除用户
function deleteUser(u) {
  axios.delete(`http://localhost:8001/api/users/${u.username}`)
    .then(() => {
      ElMessage.success('已删除')
      fetchUsers()
      logs.value.push({ time: now(), user: 'admin', action: `删除账号${u.username}`})
    })
    .catch(err => {
      ElMessage.error('删除失败: ' + err)
    })
}

// 新建/编辑用户（统一持久化！）
function saveUser() {
  if (!userForm.value.username) return ElMessage.warning('请填写用户名')
  if (!userForm.value.permissions || userForm.value.permissions.length === 0)
    userForm.value.permissions = ['dashboard']
  if (editingUser.value) {
    // 编辑
    axios.patch(`http://localhost:8001/api/users/${userForm.value.username}`, {
      role: userForm.value.role,
      permissions: userForm.value.permissions
    }).then(() => {
      ElMessage.success('编辑成功')
      fetchUsers()
      logs.value.push({ time: now(), user: 'admin', action: `编辑账号${userForm.value.username}`})
      showAddUser.value = false
      editingUser.value = false
    }).catch(err => {
      ElMessage.error('编辑失败: ' + err)
    })
  } else {
    // 新建
    axios.post('http://localhost:8001/api/users', {
      username: userForm.value.username,
      password: userForm.value.password,
      email: `${userForm.value.username}@default.mail.com`,
      role: userForm.value.role,
      permissions: userForm.value.permissions
    }).then(() => {
      ElMessage.success('创建成功')
      fetchUsers()
      logs.value.push({ time: now(), user: 'admin', action: `新建账号${userForm.value.username}`})
      showAddUser.value = false
      editingUser.value = false
    }).catch(err => {
      ElMessage.error('创建失败: ' + err)
    })
  }
}

function now() {
  const d = new Date()
  return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()} ${d.getHours()}:${d.getMinutes()}`
}
</script>

<style scoped>
.system-settings-root { padding:30px 30px 0 20px; }
</style>