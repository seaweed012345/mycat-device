<template>
  <div style="color: red; text-align: center; margin-top: 80px; font-size: 22px">
    权限不足，无法访问该模块
  </div>
</template>