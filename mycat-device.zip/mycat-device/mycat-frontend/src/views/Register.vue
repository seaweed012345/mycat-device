<template>
  <div class="main">
    <!-- 左侧LOGO与品牌信息 -->
    <div class="left">
      <!-- 静态图片建议放 public/img/logo.png 下，路径直接 /img/logo.png -->
      <img src="/img/logo.png" class="logo" alt="LOGO" />
      <div class="brand-cn">炬窝科技后台管理系统</div>
      <div class="brand-en">Juwо Tech Admin Panel</div>
    </div>
    <!-- 右侧注册表单区 -->
    <div class="right">
      <form @submit.prevent="handleRegister">
        <div class="form-title">Register</div>
        <!-- 用户名填写 -->
        <label>用户名</label>
        <input
          v-model="username"
          type="text"
          placeholder="随意填写用户名"
          required
        />
        <!-- 邮箱 -->
        <label>邮箱</label>
        <input
          v-model="email"
          type="email"
          placeholder="用于找回密码"
          required
        />
        <!-- 密码 -->
        <label>密码</label>
        <input
          v-model="password"
          type="password"
          placeholder="设置密码"
          required
        />
        <button type="submit" class="login-btn">注册</button>
        <button
          type="button"
          class="register-btn"
          @click="goLogin"
        >返回登录</button>
        <div v-if="error" class="error-msg">{{ error }}</div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const username = ref('')
const email = ref('')
const password = ref('')
const error = ref('')
const router = useRouter()

async function handleRegister() {
  if (username.value && email.value && password.value) {
    error.value = ''
    try {
      await axios.post('http://localhost:8001/api/users', {
        username: username.value,
        email: email.value,
        password: password.value,
        role: 'user',
        permissions: ['dashboard']
      })
      alert('注册成功！请登录')
      router.push('/login')
    } catch (err) {
      error.value = err.response?.data?.error || '注册失败'
    }
  } else {
    error.value = '请完整填写所有信息'
  }
}

function goLogin() {
  router.push('/login')
}
</script>

<style scoped>
/* ==== 整个页面背景和字体设置 ==== */
body {
  background: #fff;   /* 整体白色背景 */
  margin: 0;
  font-family: "微软雅黑", "Arial", sans-serif;  /* 中文优先 */
}

/* ==== 版心主容器，控制左右居中与宽度 ==== */
.main {
  width: 1200px;                /* 设置主体内容最大宽度，可调900~1400px取决于你空间需求 */
  height: 100vh;                /* 高度占满一屏，无垂直滚动条 */
  margin: 0 auto;               /* 左右居中对齐 */
  display: flex;                /* 水平弹性布局，左右双栏 */
  align-items: center;          /* 垂直方向始终居中 */
  justify-content: center;      /* 水平方向两侧撑满、整体居中 */
}

/* ==== 左侧LOGO与品牌 ==== */
.left {
  flex: 1 1 0;                  /* 左右两栏空间各占一半。可自调这个比例，如2 1 0即可左边变大 */
  display: flex;
  flex-direction: column;       /* 主轴竖直方向 */
  align-items: center;          /* 内容横向居中 */
  justify-content: center;      /* 内容纵向居中 */
}
.logo {
  width: 240px;                 /* LOGO宽度，直接调大/调小 */
  margin: 0 0 10px 0;           /* 往下隔开下面的文字 */
}
.brand-cn {
  font-size: 2.5rem;            /* 中文品牌字号 */
  color: #3582be;               /* 主色 */
  letter-spacing: 12px;          /* 字距加大，显得稳重 */
  margin: 12px 0 4px 0;         /* 上下间距 */
  font-weight: 500;             /* 字重稍微加粗 */
}
.brand-en {
  font-size: 1.35rem;           /* 英文品牌字号 */
  color: #3582be;               /* 次色/淡蓝 */
  margin-bottom: 50px;          /* 汉英之间的距离，可减少整体撑高 */
}

/* ==== 右侧表单容器（无阴影白底版本）==== */
.right {
  flex: 1 1 0;                  /* 右侧栏占一半空间。可调一致/单边大/小 */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: none;             /* 移除底色，直接贴合全局背景 */
  box-shadow: none;             /* 移除卡片阴影 */
  border-radius: 0;             /* 移除圆角 */
  padding: 0;                   /* 去掉内边距 */
}

/* ==== 登录/注册表单主体宽度与形态 ==== */
form {
  width: 340px;                 /* 表单区域主宽度。可以调宽调窄 */
  display: flex;
  flex-direction: column;
}

/* ==== 表单标题 ==== */
.form-title {
  text-align: center;
  font-size: 1.14rem;           /* 标题字体大小 */
  margin-bottom: 5px;           /* 标题与下方控件距离 */
  color: #bbb;
  letter-spacing: 2px;
}
label {
  display: block;
  margin-top: 7px;             /* 距离上方输入框距离（可收紧） */
  margin-bottom: 5px;
  color: #444;
  font-size: 0.6rem;
}

/* ==== 输入框/密码框通用样式 ==== */
input[type="text"],
input[type="password"],
input[type="email"] {
  width: 100%;
  box-sizing: border-box;
  padding: 5px 10px;           /* 内边距，控制输入区高度和舒适感 */
  border: 1px solid #d0d6e1;   /* 默认浅蓝边框 */
  border-radius: 8px;          /* 四角圆角 */
  font-size: 0.9rem;
  margin-bottom: 1px;
  outline: none;
  background: #f6faff;         /* 微淡蓝底比纯白更柔和 */
}
input[type="text"]:focus,
input[type="password"]:focus,
input[type="email"]:focus {
  border-color: #3582be;       /* 获得焦点后主色边框 */
  background: #eaf3fc;         /* 获得焦点后淡蓝底更明显 */
}

/* ==== 主按钮 ==== */
.login-btn {
  width: 100%;
  background: linear-gradient(#62a9db,#3582be);    /* 蓝色渐变 */
  color: #fff;
  border: none;
  border-radius: 6px;
  padding: 8px 0;
  font-size: 1.11rem;
  font-weight: bold;
  margin: 5px 0 10px 0;
  cursor: pointer;
  letter-spacing: 2px;
}
.login-btn:hover {
  background: linear-gradient(#3e88c0,#2362a0);
}

/* ==== 返回登录切换按钮 ==== */
.register-btn {
  width: 100%;
  background: none;             /* 透明背景，融入主背景 */
  color: #3582be;
  border: 0.8px solid #3582be;
  font-size: 1.07rem;
  border-radius: 6px;
  padding: 4px 0;
  cursor: pointer;
  transition: background .2s;
  margin-bottom: 8px;
}
.register-btn:hover {
  background: #f7fbff;         /* 悬停轻微高亮 */
}

.error-msg {
  color: #b00;
  text-align: center;
  margin: 12px 0 0 0;
  font-size: 0.95rem;
}
</style>