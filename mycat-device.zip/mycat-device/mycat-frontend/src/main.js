import { createApp } from 'vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import App from './App.vue'
import router from './router'  // 实际生效的是 src/router/index.js 内部的routes

createApp(App).use(router).use(ElementPlus).mount('#app')