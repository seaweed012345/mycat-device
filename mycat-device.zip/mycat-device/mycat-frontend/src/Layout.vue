<template>
  <div class="root-layout">
    <!-- 顶部导航栏 -->
    <header class="topbar">
      <div class="breadcrumbs">{{ pageTitle }}</div>
    </header>
    <div class="container">
      <!-- 左侧导航栏 -->
      <aside class="sidebar">
        <div class="userinfo">
          <div>欢迎：<b>{{ username }}</b></div>
          <div>Permission：<b>{{ role }}</b></div>
          <button class="logout-btn" @click="logout">退出登录</button>
        </div>
        <nav class="navmenu">
          <!-- 菜单根据权限过滤 -->
          <router-link
            v-for="item in menusToShow"
            :key="item.path"
            :to="item.path"
            class="navitem"
            :class="{active: isActive(item.path)}"
          >
            <span class="navtext">{{ item.label }}</span>
          </router-link>
        </nav>
        <!-- 侧栏底部信息区 -->
        <div class="sidebar-footer">
          <div class="sidebar-time">{{ time }}</div>
          <div class="sidebar-weekday">{{ weekday }}</div>
          <div class="sidebar-date">{{ date }}</div>
        </div>
      </aside>
      <!-- 右侧主内容区（页面核心内容区域，唯一会变化）-->
      <main class="main-content">
        <router-view /><!-- 此处渲染当前路由内容页 -->
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'

// 可用菜单项，key需和路由 meta.moduleKey 保持一致！
const allMenus = [
  { path: '/', key: 'dashboard', label: '首页总览' },
  { path: '/datacenter', key: 'datacenter', label: '数据中心' },
  { path: '/device', key: 'device', label: '设备管理' },
  { path: '/aicloud', key: 'aicloud', label: 'AI云算' },
  { path: '/comm', key: 'comm', label: '通讯管理' },
  { path: '/wechat', key: 'wechat', label: '微信商城' },
  { path: '/system', key: 'system', label: '系统设置' },
  { path: '/stats', key: 'stats', label: '运行统计' }
]

const username = ref('未登录')
const role = ref('未设置')
const permissions = ref([])
// 读取登录信息和权限
onMounted(() => {
  const local = localStorage.getItem('currentUser')
  if (local) {
    try {
      const user = JSON.parse(local)
      username.value = user.username || '未登录'
      role.value = user.role || user.permission || '未设置'
    } catch (e) { /* Ignore */ }
  }
  // 读取权限
  try {
    permissions.value = JSON.parse(localStorage.getItem('permissions') || '[]')
  } catch {
    permissions.value = []
  }
})
// 只展示有权限的菜单项，【admin拥有全部权限】
const menusToShow = computed(() =>
  allMenus.filter(
    m => permissions.value.includes('admin') || permissions.value.includes(m.key)
  )
)

const router = useRouter()
const route = useRoute()

// 高亮当前菜单
const isActive = path => route.path === path || (path === '/' && route.path === '')

// 自动面包屑/大标题
const pageTitle = computed(() => {
  const curr = allMenus.find(i => i.path === route.path)
  return curr ? curr.label : ''
})

// 退出登录
function logout() {
  localStorage.removeItem('currentUser');
  localStorage.removeItem('permissions');
  router.push('/login')
}

// ========== 侧边栏底部时间 ==========
const time = ref('')
const weekday = ref('')
const date = ref('')
function updateTime() {
  const now = new Date()
  const pad = n => n.toString().padStart(2, '0')
  time.value = `${pad(now.getHours())}:${pad(now.getMinutes())}`
  const weekMap = ['星期日','星期一','星期二','星期三','星期四','星期五','星期六']
  weekday.value = weekMap[now.getDay()]
  date.value = `${now.getFullYear()}/${pad(now.getMonth()+1)}/${pad(now.getDate())}`
}
onMounted(() => {
  updateTime()
  setInterval(updateTime, 1000 * 20)
})
</script>

<style scoped>
/* ======主布局设置======== */
body {
  background: #fff; margin: 0;
  font-family: "微软雅黑", Arial, sans-serif;
  min-height: 1440px;
}

/* 顶部导航栏尺寸与样式 */
.topbar {
  position: fixed;
  top: 0; left: 0; right: 0;
  height: 30px;
  background: #fafafa;
  border-bottom: 1.5px solid #e3e3e3;
  z-index: 100;
  display: flex; align-items: center;
  padding-left: 275px;
}
.breadcrumbs {
  font-size: 1.19rem;
  color: #666;
  letter-spacing: 1.5px;
}

/* 主区左右布局 */
.container {
  display: flex;
  margin-top: 54px;
  height: calc(100vh - 54px);
  min-height: 1386px;
}

/* 左侧侧边栏（与Dashboard一致） */
.sidebar {
  width: 270px;
  background: #fcfcfc;
  border-right: 2px solid #eaeaea;
  display: flex; flex-direction: column; align-items: stretch;
  position: fixed;
  top: 45px; left: 0; bottom: 0;
  min-height: calc(90vh - 45px);
  z-index: 50;
  box-sizing: border-box;
}
.userinfo {
  padding: 50px 24px 30px 24px;
  font-size: 0.9rem;
  color: #5e5c5c;
  border-bottom: 3px solid #eee;
  letter-spacing: 1.5px;
  line-height: 3;
}
.navmenu {
  flex: 1; display: flex; flex-direction: column; gap: 16px;
  padding: 28px 0 24px 0;
}
.navitem {
  display: flex;
  align-items: center;
  font-size: 1.19rem;
  color: #252525;
  cursor: pointer;
  padding: 5px 0 5px 80px;
  margin-right: 19px;
  border-radius: 0 8px 8px 0;
  background: #cac9c9;
  border: 1px solid #f0f2f7;
  box-sizing: border-box;
  transition: background .15s, color .13s;
  text-decoration: none;
  color: inherit;
  position: relative;
}
.navitem.active,
.navitem:hover {
  background: #387ec0;
  color: #fafafa;
  border: 1.5px solid #7ab5ec;
}
.navtext {
  font-weight: 500; font-size: inherit; letter-spacing: 1px;
}

/* 侧边底部信息区 */
.sidebar-footer {
  padding: 26px 0 26px 0;
  text-align: left;
  padding-left: 50px;
}
.sidebar-time {
  color: #2361d4;
  font-size: 2.38rem;
  font-family: consolas, Arial;
  letter-spacing: 3px;
  margin-bottom: 7px;
  margin-left: 10px;
}
.sidebar-weekday {
  color: #aaa;
  margin-bottom: 8px;
  font-size: 1.17rem;
  letter-spacing: 2.2px;
  margin-left: 35px;
}
.sidebar-date {
  color: #bbb;
  font-size: 1.15rem;
  letter-spacing: 1.7px;
  margin-left: 15px;
}

/* =====右侧主内容区，router-view容器，对齐要求主内容区和原main-content一样===== */
.main-content {
  flex: 1;
  margin-left: 270px;
  padding: 60px 20px 0 20px;
  min-height: 1320px;
  box-sizing: border-box;
  display: flex; flex-direction: column; align-items: center;
}

/* 退出按钮左下角 */
.logout-btn {
  background: linear-gradient(#e2e3e4, #e5e5e6);
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 3px 70px;
  font-size: 0.7rem;
  margin-top: 10px;
  cursor: pointer;
  box-shadow: 0 2px 5px 0 #d6d6d64f;
  letter-spacing: 2px;
  transition: background 0.2s, color 0.16s;
  outline: none;
  font-family: inherit;
  margin-left: 1px;
}
.logout-btn:hover {
  background: linear-gradient(#e14f4f, #9e2222);
  color: #fff;
  box-shadow: 0 3px 12px 2px #ed8d8d3a;
}
</style>