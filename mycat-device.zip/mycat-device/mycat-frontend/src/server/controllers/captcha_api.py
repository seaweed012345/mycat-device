from flask import Blueprint, request, jsonify, send_file
from captcha.image import ImageCaptcha
import random, string, uuid
from io import BytesIO

captcha_api = Blueprint('captcha_api', __name__)
captcha_store = {}  # 生产建议用 Redis

@captcha_api.route('/api/captcha')
def get_captcha():
    code = ''.join(random.choices(string.digits, k=4))
    key = str(uuid.uuid4())
    image = ImageCaptcha()
    img_io = BytesIO()
    image.write(code, img_io)
    img_io.seek(0)
    captcha_store[key] = code
    return send_file(
        img_io, 
        mimetype='image/png', 
        headers={
            'captcha-key': key,
            'Access-Control-Expose-Headers': 'captcha-key'
        }
    )

@captcha_api.route('/api/user/login', methods=['POST'])
def login():
    data = request.json
    username = data['username']
    password = data['password']
    captcha = data.get('captcha', '')
    captcha_key = data.get('captcha_key', '')
    # 验证码检查
    valid_code = captcha_store.get(captcha_key)
    if not (valid_code and captcha.strip() == valid_code):
        return jsonify({'error': '验证码错误或已过期'}), 400
    # 清除有效码
    captcha_store.pop(captcha_key, None)
    # 账户密码检查（模拟）
    if username == 'admin' and password == '123456':
        return jsonify({'success': True, 'token': 'test-token'})
    return jsonify({'error': '用户名或密码错误'}), 400