# src/server/communications/models.py

"""
通讯管理模块的ORM模型定义
用于管理下发任务、执行日志、设备通讯状态等
如用Flask-SQLAlchemy也没问题，FastAPI用SQLModel/peewee都可以类似改写。
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, JSON, ForeignKey
from sqlalchemy.orm import declarative_base, relationship

# 如你的项目用的Base不是这里定义的，请用主项目的Base！
Base = declarative_base()

class DownlinkTask(Base):
    """定时/手动下发任务表"""
    __tablename__ = 'downlink_task'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(64), comment='任务名')
    schedule_type = Column(String(16), default='timed', comment='任务类型: timed/manual')
    cron_expr = Column(String(32), default='', comment='定时cron表达式,如0 1 * * * 表示1点')
    start_time = Column(DateTime, default=datetime.now, comment='任务开始时间')
    end_time = Column(DateTime, nullable=True, comment='任务失效时间')
    payload_template = Column(JSON, comment='下发内容模板(json)')
    target_devices = Column(JSON, comment='目标设备列表（mac列表）')
    enabled = Column(Boolean, default=True, comment='是否启用')

    logs = relationship('DownlinkLog', back_populates='task')

class DownlinkLog(Base):
    """每次任务下发执行日志"""
    __tablename__ = 'downlink_log'
    id = Column(Integer, primary_key=True, autoincrement=True)
    task_id = Column(Integer, ForeignKey('downlink_task.id'))
    device_mac = Column(String(32), comment='目标设备mac')
    sent_time = Column(DateTime, default=datetime.now, comment='下发时间')
    status = Column(String(16), default='pending', comment='状态: success/failed/timeout/pending')
    payload = Column(JSON, comment='下发数据包内容')
    response = Column(JSON, comment='设备响应内容/ACK')
    error = Column(Text, comment='异常描述')
    log_type = Column(String(16), default='auto', comment="auto/manual/handtest")

    task = relationship('DownlinkTask', back_populates='logs')

class DeviceCommStatus(Base):
    """设备通讯实时状态表，可定期刷新，便于管理台/大屏实时同步在线离线状态"""
    __tablename__ = 'device_comm_status'
    id = Column(Integer, primary_key=True, autoincrement=True)
    device_mac = Column(String(32), unique=True, comment='设备mac')
    last_online = Column(DateTime, comment='最近在线上线时间')
    last_downlink = Column(DateTime, comment='最近成功下发时间')
    last_response = Column(DateTime, comment='最近响应/ACK时间')
    downlink_count = Column(Integer, default=0, comment='累计下发包数')
    failure_count = Column(Integer, default=0, comment='累计失败次数')
    packet_loss_count = Column(Integer, default=0, comment='累计丢包次数')
    bandwidth_up = Column(Integer, default=0, comment='上行带宽(kb)')
    bandwidth_down = Column(Integer, default=0, comment='下行带宽(kb)')
    online = Column(Boolean, default=False, comment='当前是否在线')

    # 其它你想扩展的列...