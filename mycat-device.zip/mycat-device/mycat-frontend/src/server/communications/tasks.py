# src/server/communications/tasks.py

"""
通讯管理 - 任务调度与下发逻辑
- 定时查询启用的下发任务，到点自动下发
- 支持手动下发/重试
- 日志写入DownlinkLog表，更新设备实时通讯状态
"""

import json
import traceback
from datetime import datetime
from sqlalchemy.orm import Session
from apscheduler.schedulers.background import BackgroundScheduler
from communications.models import DownlinkTask, DownlinkLog, DeviceCommStatus
from communications.mqtt_client import send_downlink_mqtt
from config import get_db_session  # 项目通用session创建函数

# ========== 定时任务调度器 ==========
scheduler = BackgroundScheduler()

def schedule_all_downlink_tasks():
    """初始化调度，把所有有效的定时下发任务加��APScheduler"""
    session: Session = get_db_session()
    tasks = session.query(DownlinkTask).filter_by(enabled=True).all()
    for task in tasks:
        _register_task_to_scheduler(task)
    print(f"已注册{len(tasks)}个通讯下发任务")
    session.close()

def _register_task_to_scheduler(task: DownlinkTask):
    """内部函数：将任务注册给APScheduler（cron形式）"""
    if task.schedule_type == 'timed' and task.cron_expr:
        scheduler.add_job(
            func=run_downlink_task,           # 定时调度的主入口
            trigger='cron',
            id=f"downlink_{task.id}",
            **_parse_cron_expr(task.cron_expr),
            args=[task.id]
        )
        print(f"任务[{task.name}]已加入调度器。")

def _parse_cron_expr(expr: str):
    """将crontab表达式解析为apscheduler可用参数"""
    # 支持简单: "0 1 * * *"
    minute, hour, day, month, day_of_week = expr.split()
    return dict(
        minute=minute, hour=hour, day=day, month=month, day_of_week=day_of_week
    )

# ========== 下发任务主过程 ==========
def run_downlink_task(task_id: int, manual_payload: dict = None, manual_devices: list = None):
    """
    执行一次通讯下发任务
    :param task_id: 任务ID（数据库主键）
    :param manual_payload: 若手动下发、允许指定payload覆盖模板
    :param manual_devices: 若手动/调试下发、可仅指定一批设备
    """
    session: Session = get_db_session()
    task = session.query(DownlinkTask).filter_by(id=task_id).first()
    if not task:
        print(f"找不到下发任务 id={task_id}")
        session.close()
        return

    # 下发设备列表与内容
    payload = manual_payload if manual_payload else task.payload_template
    device_list = manual_devices if manual_devices else (task.target_devices or [])
    now_time = datetime.now()

    for mac in device_list:
        log = DownlinkLog(
            task_id=task.id,
            device_mac=mac,
            sent_time=now_time,
            payload=payload,
            status='pending',
            log_type='manual' if manual_devices else 'auto'
        )
        session.add(log)
        session.commit() # 提交以便日志有id，后续方便查

        try:
            # ========== 实际MQTT下发 ==========
            resp = send_downlink_mqtt(mac, payload)  # 你的mqtt_client.py负责实现
            log.status = 'success' if resp.get('status') == 'ok' else 'failed'
            log.response = resp
            # ========== 实时通讯状态表更新 ==========
            device_stat = session.query(DeviceCommStatus).filter_by(device_mac=mac).first()
            if not device_stat:
                device_stat = DeviceCommStatus(device_mac=mac)
                session.add(device_stat)
            device_stat.last_online = datetime.now()
            device_stat.last_downlink = datetime.now()
            if log.status == 'success':
                device_stat.downlink_count += 1
                device_stat.online = True
                device_stat.failure_count = 0
            else:
                device_stat.failure_count += 1
            session.commit()

        except Exception as e:
            log.status = 'failed'
            log.error = traceback.format_exc()
            print(f"下发失败 mac={mac} error={e}")
            # 设备状态失败+1
            device_stat = session.query(DeviceCommStatus).filter_by(device_mac=mac).first()
            if not device_stat:
                device_stat = DeviceCommStatus(device_mac=mac)
                session.add(device_stat)
            device_stat.failure_count += 1
            session.commit()

    session.close()


# ========== 外部接口：单次手动下发 ==========
def manual_downlink(task_id: int, device_mac: str, payload: dict):
    """
    手动立即对指定设备下发指定payload
    """
    run_downlink_task(task_id, manual_payload=payload, manual_devices=[device_mac])

# ========== APScheduler 启动入口 ==========
def start_comm_scheduler():
    """项目启动时调用一次，启动调度器+注册全部任务"""
    schedule_all_downlink_tasks()
    scheduler.start()
    print("通讯下发调度器已启动")