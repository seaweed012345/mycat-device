# src/server/communications/mqtt_client.py

"""
负责与本地机（如ESP32设备）实现MQTT通信、指令下发和应答收集
对外主接口：send_downlink_mqtt(mac, payload)
"""

import time
import json
import threading
from paho.mqtt import client as mqtt
from queue import Queue

# MQTT连接配置——请按实际调整
MQTT_BROKER = 'your.mqtt.broker.ip'
MQTT_PORT = 1883
MQTT_USER = 'your_user'      # 如需身份认证
MQTT_PASS = 'your_pass'
MQTT_KEEPALIVE = 60

# 主题模板，与ESP32一致
DOWNLINK_TOPIC = "cat-cabinet/{mac}/command"
RESPONSE_TOPIC = "cat-cabinet/{mac}/ack"

# 用队列/字典管理响应——用于同步等待本地机的回包/反馈
response_queue_dict = {}

# ========== MQTT客户端全局初始化 ==========
mqtt_client = mqtt.Client()

def _on_connect(cli, userdata, flags, rc):
    print("MQTT连接完成，返回码:", rc)

def _on_message(cli, userdata, msg):
    topic = msg.topic
    payload = msg.payload.decode()
    try:
        data = json.loads(payload)
    except Exception:
        data = payload
    # 判断是否为ack/应答包
    if '/ack' in topic:
        mac = topic.split('/')[1]
        if mac in response_queue_dict:
            response_queue_dict[mac].put(data)
    else:
        pass  # 可根据需要处理其它下行/上行消息

def connect_mqtt():
    mqtt_client.username_pw_set(MQTT_USER, MQTT_PASS)
    mqtt_client.on_connect = _on_connect
    mqtt_client.on_message = _on_message
    mqtt_client.connect(MQTT_BROKER, MQTT_PORT, MQTT_KEEPALIVE)
    # 单独线程循环
    thread = threading.Thread(target=mqtt_client.loop_forever, daemon=True)
    thread.start()
    print("MQTT后台监听线程已启动")

# ========== 主接口：下发指令 ==========
def send_downlink_mqtt(mac: str, payload: dict, timeout=5):
    """
    向指定设备下发指令，并同步等待其ack响应
    :param mac: 设备mac（或唯一ID，与本地机一致）
    :param payload: 下发内容（json/dict）
    :param timeout: 超时时间，秒
    :return: 设备回包内容或超时报错
    """
    # --- 订阅ACK主题，建立消息队列
    if mac not in response_queue_dict:
        response_queue_dict[mac] = Queue()
        mqtt_client.subscribe(RESPONSE_TOPIC.format(mac=mac))
    # --- 下发
    mqtt_client.publish(DOWNLINK_TOPIC.format(mac=mac), json.dumps(payload))
    print(f"[MQTT] 下发到设备 {mac} ：", payload)
    try:
        ack = response_queue_dict[mac].get(timeout=timeout)
        print(f"[MQTT] 收到设备回包 {mac} ：", ack)
        return ack
    except Exception as e:
        print(f"[MQTT] 设备{mac} 无应答/超时：", e)
        return {"status": "timeout", "msg": "设备无应答"}

# ========== 启动MQTT连接 ==========

# 项目主入口或tasks.py中import时，记得调用一次connect_mqtt()
# 通常在项目启动完成后执行（以保证连接自动重连）

# connect_mqtt()  # 查看调用时机
