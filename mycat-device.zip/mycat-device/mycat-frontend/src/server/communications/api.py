# src/server/communications/api.py

"""
通讯管理模块 - 对外RESTful API接口
- 任务管理（新建、查询、修改、删除下发任务/时间段）
- 设备状态与任务日志查询
- 手动下发/重试
- 对接前端(Vue/React/管理后台)、也适用于小程序调用获取下发内容、设备状态
"""

from flask import Blueprint, request, jsonify
from sqlalchemy.orm import Session
from communications.models import DownlinkTask, DownlinkLog, DeviceCommStatus
from communications.tasks import run_downlink_task, manual_downlink
from config import get_db_session

comm_bp = Blueprint('comm_bp', __name__)

### ========== 下发任务管理 ==========

@comm_bp.route('/tasks', methods=['GET'])
def list_tasks():
    """获取所有下发任务"""
    session: Session = get_db_session()
    tasks = session.query(DownlinkTask).all()
    result = []
    for t in tasks:
        result.append({
            "id": t.id,
            "name": t.name,
            "schedule_type": t.schedule_type,
            "cron_expr": t.cron_expr,
            "start_time": t.start_time,
            "end_time": t.end_time,
            "payload_template": t.payload_template,
            "target_devices": t.target_devices,
            "enabled": t.enabled,
        })
    session.close()
    return jsonify(result)

@comm_bp.route('/tasks', methods=['POST'])
def create_task():
    """新增下发任务"""
    data = request.get_json()
    session: Session = get_db_session()
    task = DownlinkTask(
        name = data.get('name'),
        schedule_type = data.get('schedule_type', 'timed'),
        cron_expr = data.get('cron_expr', ''),
        start_time = data.get('start_time'),
        end_time = data.get('end_time'),
        payload_template = data.get('payload_template', {}),
        target_devices = data.get('target_devices', []),
        enabled = data.get('enabled', True)
    )
    session.add(task)
    session.commit()
    session.close()
    return jsonify({"msg": "创建成功", "id": task.id})

@comm_bp.route('/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    """编辑/启停下发任务"""
    data = request.get_json()
    session: Session = get_db_session()
    task = session.query(DownlinkTask).filter_by(id=task_id).first()
    if not task:
        return jsonify({"error": "任务不存在"}), 404
    task.name = data.get('name', task.name)
    task.schedule_type = data.get('schedule_type', task.schedule_type)
    task.cron_expr = data.get('cron_expr', task.cron_expr)
    task.start_time = data.get('start_time', task.start_time)
    task.end_time = data.get('end_time', task.end_time)
    task.payload_template = data.get('payload_template', task.payload_template)
    task.target_devices = data.get('target_devices', task.target_devices)
    task.enabled = data.get('enabled', task.enabled)
    session.commit()
    session.close()
    return jsonify({"msg": "修改成功"})

@comm_bp.route('/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    """删除下发任务"""
    session: Session = get_db_session()
    task = session.query(DownlinkTask).filter_by(id=task_id).first()
    if not task:
        return jsonify({"error": "任务不存在"}), 404
    session.delete(task)
    session.commit()
    session.close()
    return jsonify({"msg": "删除成功"})


### ========== 任务日志查询 ==========

@comm_bp.route('/logs', methods=['GET'])
def get_logs():
    """查询下发日志，可按任务/设备/time筛选"""
    session: Session = get_db_session()
    task_id = request.args.get('task_id')
    device_mac = request.args.get('device_mac')
    q = session.query(DownlinkLog)
    if task_id:
        q = q.filter_by(task_id=task_id)
    if device_mac:
        q = q.filter_by(device_mac=device_mac)
    logs = q.order_by(DownlinkLog.sent_time.desc()).limit(200).all()
    result = []
    for log in logs:
        result.append({
            "id": log.id,
            "task_id": log.task_id,
            "device_mac": log.device_mac,
            "sent_time": log.sent_time,
            "status": log.status,
            "payload": log.payload,
            "response": log.response,
            "error": log.error,
            "log_type": log.log_type
        })
    session.close()
    return jsonify(result)


### ========== 设备通讯状态 ==========

@comm_bp.route('/device_status', methods=['GET'])
def device_status():
    """所有设备通讯实时状态/带宽/掉线统计"""
    session: Session = get_db_session()
    devices = session.query(DeviceCommStatus).all()
    result = []
    for d in devices:
        result.append({
            "device_mac": d.device_mac,
            "last_online": d.last_online,
            "last_downlink": d.last_downlink,
            "last_response": d.last_response,
            "downlink_count": d.downlink_count,
            "failure_count": d.failure_count,
            "packet_loss_count": d.packet_loss_count,
            "bandwidth_up": d.bandwidth_up,
            "bandwidth_down": d.bandwidth_down,
            "online": d.online
        })
    session.close()
    return jsonify(result)

### ========== 手动下发测试 ==========

@comm_bp.route('/manual_downlink', methods=['POST'])
def manual_downlink_api():
    """手动对指定设备下发指定消息"""
    data = request.get_json()
    task_id = data.get('task_id')
    device_mac = data.get('device_mac')
    payload = data.get('payload')
    if not (task_id and device_mac and payload):
        return jsonify({"error": "参数缺失"}), 400
    manual_downlink(task_id, device_mac, payload)
    return jsonify({"msg": "手动下发已触发，请关注日志"})

### ========== 前端或小程序端 获取下发内容 ==========

@comm_bp.route('/downlink_content/<device_mac>', methods=['GET'])
def get_downlink_content(device_mac):
    """
    前端/微信小程序 拉取当前设备的最新下发内容（配合二维码/扫码触发)
    """
    # 例如：查找该设备所属分组最近的一次下发任务内容。不做持久同步推送时前端用此接口
    session: Session = get_db_session()
    task = session.query(DownlinkTask).order_by(DownlinkTask.id.desc()).first()  # 或自定义查找逻辑
    payload = {}
    if task:
        payload = task.payload_template
    session.close()
    return jsonify(payload)
