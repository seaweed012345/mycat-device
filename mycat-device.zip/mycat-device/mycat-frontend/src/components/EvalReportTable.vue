<template>
  <div>
    <div>
      搜索:
      <input v-model="keyword" placeholder="mac/日期/分级/品种等"/>
      <button @click="loadData">搜索</button>
    </div>
    <table>
      <thead>
        <tr>
          <th>mac</th><th>品种</th><th>性别</th>
          <th>评估时间</th><th>分数</th><th>分级</th>
          <th>主解释</th><th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in tableData" :key="item.report_id">
          <td>{{item.mac}}</td>
          <td>{{item.breed}}</td>
          <td>{{item.sex}}</td>
          <td>{{item.analyze_time}}</td>
          <td>{{item.score}}</td>
          <td>{{item.score_level}}</td>
          <td>{{item.main_triggers?.join('、')}}</td>
          <td>
            <button @click="detail(item.report_id)">详情</button>
            <button @click="rerun(item.report_id)">再分析</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import {ref, watch, onMounted} from 'vue'
import axios from 'axios'
const props = defineProps(['evalPeriod'])
const keyword = ref('')
const tableData = ref([])

async function loadData() {
  // 增加 period 入参
  const resp = await axios.get('/api/health/report/list', {
    params: { period: props.evalPeriod, search: keyword.value }
  })
  tableData.value = resp.data
}
onMounted(loadData)
watch(() => props.evalPeriod, loadData)

function detail(report_id) {
  // 打开详情弹窗，拉 /api/health/report/detail?report_id=...
  // 这里建议用 ElDialog/Modal + JsonView 展示所有字段
}
function rerun(report_id) {
  // 拉 /api/health/report/rerun 并刷新/提示
}
</script>