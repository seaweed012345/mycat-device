// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'

import Login from '../views/Login.vue'
import Register from '../views/Register.vue'
import Dashboard from '../views/Dashboard.vue'
import Datacenter from '../views/Datacenter.vue'
import DeviceManager from '../views/DeviceManager.vue'
import SystemSettings from '../views/SystemSettings.vue'
import StatsDashboard from '../views/StatsDashboard.vue'
const AdminEvalConfig = () => import('../views/AdminEvalConfig.vue')
const CommManager = () => import('../views/CommManager.vue')
import Layout from '../Layout.vue' // 主框架

// 新增无权限页
const NotAllowed = () => import('../views/NotAllowed.vue')

export const allMenus = [
  { name: "首页总览", key: "dashboard", path: "/" },
  { name: "数据中心", key: "datacenter", path: "/datacenter" },
  { name: "设备管理", key: "device", path: "/device" },
  { name: "AI云算", key: "aicloud", path: "/aicloud" },
  { name: "通讯管理", key: "comm", path: "/comm" },
  { name: "系统设置", key: "system", path: "/system" },
  { name: "运行统计", key: "stats", path: "/stats" }
  // ...如有其它业务菜单，请自行补全
]

const routes = [
  { path: '/login', component: Login },
  { path: '/register', component: Register },
  {
    path: '/',
    component: Layout,
    children: [
      { path: '', component: Dashboard, meta: { moduleKey: 'dashboard' }},
      { path: 'datacenter', component: Datacenter, meta: { moduleKey: 'datacenter' }},
      { path: 'device', component: DeviceManager, meta: { moduleKey: 'device' }},
      { path: 'aicloud', component: AdminEvalConfig, meta: { moduleKey: 'aicloud' }},
      { path: 'comm', component: CommManager, meta: { moduleKey: 'comm' }},
      { path: 'system', component: SystemSettings, meta: { moduleKey: 'system' }},
      { path: 'stats', component: StatsDashboard, meta: { moduleKey: 'stats' }},
    ]
  },
  { path: '/not-allowed', component: NotAllowed },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// ========== 权限守卫 =============
// 权限建议存 localStorage： localStorage.setItem('permissions', JSON.stringify(['dashboard','device','datacenter']))
// 或用 pinia/vuex 的 user store
router.beforeEach((to, from, next) => {
  // 超管/admin直接放行
  let permissions = [];
  try {
    permissions = JSON.parse(localStorage.getItem('permissions') || '[]');
  } catch {
    permissions = [];
  }
  // 如果在not-allowed、login、register等公共页也放行
  if (!to.meta || !to.meta.moduleKey) return next();

  if(permissions.includes('admin') || permissions.includes(to.meta.moduleKey)) {
    return next();
  } else {
    return next('/not-allowed');
  }
});

export default router