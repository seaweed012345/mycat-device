# models/health_report.py
from . import db

class HealthEvalConfig(db.Model):
    __tablename__ = 'health_eval_config'
    id = db.Column(db.Integer, primary_key=True)
    eval_period = db.Column(db.String(32), default='23-0')

class HealthReport(db.Model):
    __tablename__ = 'health_report'
    report_id = db.Column(db.Integer, primary_key=True)
    mac = db.Column(db.String(32))
    breed = db.Column(db.String(32))
    sex = db.Column(db.String(8))
    analyze_time = db.Column(db.String(32))
    score = db.Column(db.Float)
    score_level = db.Column(db.String(16))
    main_triggers = db.Column(db.String(256))      # 存json或以 , 隔字符串
    all_triggers = db.Column(db.String(256))
    raw_risk_dict = db.Column(db.Text)  # 存json字符串
    cat_obj_stats = db.Column(db.Text)
    feedback_dict = db.Column(db.Text)
    comment = db.Column(db.String(256), default='')

    def to_dict(self):
        import json
        # 将json字段自动转为对象
        return {
            'report_id': self.report_id,
            'mac': self.mac,
            'breed': self.breed,
            'sex': self.sex,
            'analyze_time': self.analyze_time,
            'score': self.score,
            'score_level': self.score_level,
            'main_triggers': self.main_triggers.split(',') if self.main_triggers else [],
            'all_triggers': self.all_triggers.split(',') if self.all_triggers else [],
            'raw_risk_dict': json.loads(self.raw_risk_dict) if self.raw_risk_dict else {},
            'cat_obj_stats': json.loads(self.cat_obj_stats) if self.cat_obj_stats else {},
            'feedback_dict': json.loads(self.feedback_dict) if self.feedback_dict else {},
            'comment': self.comment
        }