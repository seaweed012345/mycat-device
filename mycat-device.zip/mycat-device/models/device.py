# models/device.py
from datetime import datetime
from . import db

class Device(db.Model):
    __tablename__ = 'device'
    id = db.Column(db.Integer, primary_key=True)
    mac = db.Column(db.String(32), unique=True, nullable=False)
    sn = db.Column(db.String(64))         # 设备序号可用
    alias = db.Column(db.String(64))      # 用户自定义名
    group = db.Column(db.String(32))
    status = db.Column(db.String(16))
    owner = db.Column(db.String(32))
    phone = db.Column(db.String(32))
    createTime = db.Column(db.String(32)) # 建议存字符串，或用datetime

    # 拓展字段
    breed = db.Column(db.String(32))
    age = db.Column(db.String(16))
    gender = db.Column(db.String(8))
    neutered = db.Column(db.Boolean)
    create_time = db.Column(db.DateTime, default=datetime.now)

    def to_dict(self):
        return {
            'id': self.id,
            'mac': self.mac,
            'sn': self.sn,
            'alias': self.alias,
            'group': self.group,
            'status': self.status,
            'owner': self.owner,
            'phone': self.phone,
            'createTime': self.createTime,
            'breed': self.breed,
            'age': self.age,
            'gender': self.gender,
            'neutered': self.neutered,
        }

class DeviceStatus(db.Model):
    __tablename__ = 'device_status'
    id = db.Column(db.Integer, primary_key=True)
    device_mac = db.Column(db.String(32), db.ForeignKey('device.mac'))
    feed = db.Column(db.String(32))
    feed_time = db.Column(db.DateTime)
    water = db.Column(db.String(32))
    water_time = db.Column(db.DateTime)
    excretion = db.Column(db.String(32))
    weight = db.Column(db.String(16))
    excretion_time = db.Column(db.DateTime)
    heart_rate = db.Column(db.Integer)
    hrv = db.Column(db.Integer)
    hr_time = db.Column(db.DateTime)
    sensor_data = db.Column(db.String(128))
    temperature = db.Column(db.String(16))
    humidity = db.Column(db.String(16))
    env_time = db.Column(db.DateTime)
    air_quality = db.Column(db.String(16))
    co2 = db.Column(db.String(16))
    co2_time = db.Column(db.DateTime)
    update_time = db.Column(db.DateTime, default=datetime.now)

class DeviceAI(db.Model):
    __tablename__ = 'device_ai'
    id = db.Column(db.Integer, primary_key=True)
    device_mac = db.Column(db.String(32), db.ForeignKey('device.mac'))
    health_score = db.Column(db.String(16))
    ai_assess = db.Column(db.String(256))
    ai_time = db.Column(db.DateTime)
    filter_status = db.Column(db.String(16))
    filter_remain = db.Column(db.String(16))
    filter_time = db.Column(db.DateTime)

class DeviceFeedback(db.Model):
    __tablename__ = 'device_feedback'
    id = db.Column(db.Integer, primary_key=True)
    device_mac = db.Column(db.String(32), db.ForeignKey('device.mac'))
    feedback = db.Column(db.String(128))
    feedback_time = db.Column(db.DateTime)

class DeviceAuth(db.Model):
    __tablename__ = 'device_auth'
    id = db.Column(db.Integer, primary_key=True)
    device_mac = db.Column(db.String(32))
    username = db.Column(db.String(64))
    type = db.Column(db.String(32))
    expire = db.Column(db.String(32))

# ====== 设备与用户多对多绑定【关键】======
class DeviceUser(db.Model):
    __tablename__ = 'device_user'
    id = db.Column(db.Integer, primary_key=True)
    device_mac = db.Column(db.String(32), db.ForeignKey('device.mac'))
    user_openid = db.Column(db.String(64))   # 每个微信用户的openid
    role = db.Column(db.String(16), default='owner')  # 'owner', 'viewer'
    bind_time = db.Column(db.DateTime, default=datetime.now)