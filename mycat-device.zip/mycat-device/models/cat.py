from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
import datetime

Base = declarative_base()

class Cat(Base):
    __tablename__ = 'cat_profile'
    cat_id = Column(Integer, primary_key=True, autoincrement=True)
    device_sn = Column(String(64), unique=True, nullable=False)
    name = Column(String(32), nullable=False)
    gender = Column(Integer, nullable=False)
    breed = Column(String(64))
    age_months = Column(Integer)
    sterilized = Column(Boolean)
    register_time = Column(DateTime, default=datetime.datetime.utcnow)