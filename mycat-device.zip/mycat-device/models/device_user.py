from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
db = SQLAlchemy()

class DeviceUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.Integer, db.ForeignKey("device.id"))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    role = db.Column(db.String(10), default="viewer")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)