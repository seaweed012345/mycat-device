# models/comm.py
from . import db
from datetime import datetime
import json

class CommTask(db.Model):
    __tablename__ = 'comm_task'   # 修正表名！
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    schedule_type = db.Column(db.String(16), default='timed')  # 'timed' or 'manual'
    cron_expr = db.Column(db.String(64))
    target_devices = db.Column(db.Text)  # json字符串（设备mac列表）
    enabled = db.Column(db.Boolean, default=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'schedule_type': self.schedule_type,
            'cron_expr': self.cron_expr,
            'target_devices': json.loads(self.target_devices) if self.target_devices else [],
            'enabled': self.enabled,
        }

class CommLog(db.Model):
    __tablename__ = 'comm_log'
    id = db.Column(db.Integer, primary_key=True)
    sent_time = db.Column(db.DateTime, default=datetime.now)
    task_id = db.Column(db.Integer)
    device_mac = db.Column(db.String(32))
    payload = db.Column(db.Text)
    status = db.Column(db.String(16))   # success, failed
    response = db.Column(db.Text)
    error = db.Column(db.Text)

    def to_dict(self):
        return {
            'id': self.id,
            'sent_time': self.sent_time.strftime('%Y-%m-%d %H:%M:%S') if self.sent_time else '',
            'task_id': self.task_id,
            'device_mac': self.device_mac,
            'payload': self.payload,
            'status': self.status,
            'response': self.response,
            'error': self.error
        }

class CommDeviceStatus(db.Model):
    __tablename__ = 'comm_device_status'   # 保持独立正常即可
    id = db.Column(db.Integer, primary_key=True)
    device_mac = db.Column(db.String(32))
    online = db.Column(db.Boolean)
    last_online = db.Column(db.DateTime)
    downlink_count = db.Column(db.Integer, default=0)
    failure_count = db.Column(db.Integer, default=0)
    def to_dict(self):
        return {
            'device_mac': self.device_mac,
            'online': self.online,
            'last_online': self.last_online.strftime('%Y-%m-%d %H:%M:%S') if self.last_online else '',
            'downlink_count': self.downlink_count,
            'failure_count': self.failure_count
        }