# src/server/models/datacenter.py
from flask_sqlalchemy import SQLAlchemy
from . import db

class DeviceData(db.Model):
    __tablename__ = 'device_data'
    id = db.Column(db.Integer, primary_key=True)
    mac = db.Column(db.String(32), nullable=False)
    in_feed = db.Column(db.String(64))
    in_water = db.Column(db.String(64))
    out_weight = db.Column(db.String(64))
    hr_hrv = db.Column(db.String(64))
    env_temp = db.Column(db.String(64))
    env_air = db.Column(db.String(64))
    env_co2 = db.Column(db.String(64))
    breed = db.Column(db.String(32))
    age = db.Column(db.String(32))
    gender = db.Column(db.String(8))
    neutered = db.Column(db.String(8))
    health_eval = db.Column(db.String(256))
    feedback = db.Column(db.String(256))
    filter_effect = db.Column(db.String(32))

    def to_dict(self):
        return {col.name: getattr(self, col.name) for col in self.__table__.columns}