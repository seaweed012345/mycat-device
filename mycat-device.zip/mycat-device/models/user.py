from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import Column, String
import json

from . import db

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    wx_openid = Column(String(64), unique=True, nullable=True, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(64), default='viewer')
    permissions = db.Column(db.Text, default='["dashboard"]')   # 新增权限字段，存json字符串
    create_time = db.Column(db.DateTime, server_default=db.func.now())

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def set_permissions(self, perm_list):
        self.permissions = json.dumps(perm_list)

    def get_permissions(self):
        try:
            return json.loads(self.permissions)
        except Exception:
            return ['dashboard']